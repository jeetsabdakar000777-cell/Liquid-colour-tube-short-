import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Sparkles, Coins, Lightbulb, RotateCcw, PlusCircle, RefreshCw, Trophy, Tv, Play } from 'lucide-react';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';

interface SpinWheelModalProps {
  coins: number;
  freeSpins: number;
  isDailySpinAvailable?: boolean;
  onClose: () => void;
  onRewardAwarded: (reward: WheelReward) => void;
  onDeductCoins: (amount: number) => boolean;
  onWatchRewardedSpin?: () => void;
}

export interface WheelReward {
  id: string;
  label: string;
  type: 'coins' | 'hint' | 'undo' | 'extraTube' | 'freeSpin' | 'jackpot';
  amount: number;
  color: string;
  iconName: string;
}

const WHEEL_REWARDS: WheelReward[] = [
  { id: '1', label: '100 Coins', type: 'coins', amount: 100, color: '#3B82F6', iconName: 'coins' },
  { id: '2', label: '+2 Hints', type: 'hint', amount: 2, color: '#F59E0B', iconName: 'hint' },
  { id: '3', label: '200 Coins', type: 'coins', amount: 200, color: '#10B981', iconName: 'coins' },
  { id: '4', label: '+1 Tube', type: 'extraTube', amount: 1, color: '#8B5CF6', iconName: 'tube' },
  { id: '5', label: '500 Coins', type: 'coins', amount: 500, color: '#EC4899', iconName: 'coins' },
  { id: '6', label: '+2 Undos', type: 'undo', amount: 2, color: '#06B6D4', iconName: 'undo' },
  { id: '7', label: '150 Coins', type: 'coins', amount: 150, color: '#6366F1', iconName: 'coins' },
  { id: '8', label: 'Free Spin', type: 'freeSpin', amount: 1, color: '#14B8A6', iconName: 'spin' },
  { id: '9', label: '300 Coins', type: 'coins', amount: 300, color: '#F97316', iconName: 'coins' },
  { id: '10', label: '+1 Hint', type: 'hint', amount: 1, color: '#EAB308', iconName: 'hint' },
  { id: '11', label: '+1 Undo', type: 'undo', amount: 1, color: '#0EA5E9', iconName: 'undo' },
  { id: '12', label: '1000 JACKPOT', type: 'jackpot', amount: 1000, color: '#EF4444', iconName: 'jackpot' },
];

export const SpinWheelModal: React.FC<SpinWheelModalProps> = ({
  coins,
  freeSpins,
  isDailySpinAvailable = false,
  onClose,
  onRewardAwarded,
  onDeductCoins,
  onWatchRewardedSpin,
}) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [currentRotation, setCurrentRotation] = useState(0);
  const [wonReward, setWonReward] = useState<WheelReward | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const bgCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const numSlices = WHEEL_REWARDS.length;
  const sliceAngle = (2 * Math.PI) / numSlices;

  // Background animated particle canvas for video-level luxury ambience
  useEffect(() => {
    const canvas = bgCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = canvas.offsetWidth || 360);
    let height = (canvas.height = canvas.offsetHeight || 500);

    const particles: Array<{
      x: number;
      y: number;
      r: number;
      speedY: number;
      speedX: number;
      opacity: number;
      color: string;
    }> = [];

    const goldColors = ['#fde047', '#f59e0b', '#38bdf8', '#c084fc', '#ffffff'];
    for (let i = 0; i < 28; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        r: 1 + Math.random() * 2.5,
        speedY: 0.3 + Math.random() * 0.7,
        speedX: (Math.random() - 0.5) * 0.4,
        opacity: 0.3 + Math.random() * 0.6,
        color: goldColors[Math.floor(Math.random() * goldColors.length)],
      });
    }

    let time = 0;
    const renderBg = () => {
      time += 0.025;
      ctx.clearRect(0, 0, width, height);

      // Rotating radiant golden light rays in center
      ctx.save();
      ctx.translate(width / 2, height * 0.42);
      ctx.rotate(time * 0.2);
      const numRays = 12;
      for (let r = 0; r < numRays; r++) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        const rayAngle = (r * 2 * Math.PI) / numRays;
        ctx.arc(0, 0, width * 0.8, rayAngle - 0.12, rayAngle + 0.12);
        ctx.closePath();
        ctx.fillStyle = r % 2 === 0 ? 'rgba(250, 204, 21, 0.05)' : 'rgba(56, 189, 248, 0.04)';
        ctx.fill();
      }
      ctx.restore();

      // Floating sparkles
      particles.forEach((p, idx) => {
        p.y -= p.speedY;
        p.x += p.speedX + Math.sin(time + idx) * 0.3;
        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.opacity * (0.6 + Math.sin(time * 2 + idx) * 0.4);
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      animId = requestAnimationFrame(renderBg);
    };

    renderBg();
    return () => cancelAnimationFrame(animId);
  }, []);

  // Draw the Prize Wheel on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 320;
    canvas.width = size;
    canvas.height = size;
    const center = size / 2;
    const radius = size / 2 - 14;

    ctx.clearRect(0, 0, size, size);

    // Draw slices
    WHEEL_REWARDS.forEach((item, i) => {
      const startAngle = i * sliceAngle;
      const endAngle = startAngle + sliceAngle;

      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.arc(center, center, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = item.color;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#0f172a';
      ctx.stroke();

      // Text label inside slice
      ctx.save();
      ctx.translate(center, center);
      ctx.rotate(startAngle + sliceAngle / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px Plus Jakarta Sans, sans-serif';
      ctx.shadowColor = 'rgba(0,0,0,0.6)';
      ctx.shadowBlur = 4;
      ctx.fillText(item.label, radius - 18, 4);
      ctx.restore();
    });

    // Outer rim border with gold studs
    ctx.beginPath();
    ctx.arc(center, center, radius, 0, 2 * Math.PI);
    ctx.lineWidth = 8;
    ctx.strokeStyle = '#f59e0b';
    ctx.stroke();

    // Decorative studs
    for (let i = 0; i < numSlices * 2; i++) {
      const angle = (i * Math.PI) / numSlices;
      const x = center + (radius + 2) * Math.cos(angle);
      const y = center + (radius + 2) * Math.sin(angle);
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, 2 * Math.PI);
      ctx.fillStyle = '#fde68a';
      ctx.fill();
    }

    // Center hub
    ctx.beginPath();
    ctx.arc(center, center, 24, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#fbbf24';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(center, center, 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#38bdf8';
    ctx.fill();
  }, [sliceAngle, numSlices]);

  const handleSpin = () => {
    if (isSpinning) return;

    // Check if free spin or costs 50 coins
    if (freeSpins <= 0) {
      const success = onDeductCoins(50);
      if (!success) {
        sound.playError();
        return;
      }
    }

    sound.playClick();
    setIsSpinning(true);
    setWonReward(null);

    // Random landing segment
    const targetIndex = Math.floor(Math.random() * numSlices);
    const targetReward = WHEEL_REWARDS[targetIndex];

    // Number of full rotations (5-8 full spins for excitement)
    const fullSpins = 5 + Math.floor(Math.random() * 3);
    // Pin is at TOP (angle 270 deg / 1.5 * PI in standard canvas).
    // In our canvas, slice 0 starts at 0 deg (right side).
    // To land targetIndex at the top needle (270 deg):
    const sliceCenterDeg = (targetIndex + 0.5) * (360 / numSlices);
    const targetAngle = fullSpins * 360 + (270 - sliceCenterDeg);
    const finalRot = currentRotation + targetAngle;

    setCurrentRotation(finalRot);

    // Tick audio loop
    let tickCount = 0;
    const tickInterval = setInterval(() => {
      tickCount++;
      sound.playSpinTick();
      if (tickCount > 28) {
        clearInterval(tickInterval);
      }
    }, 120);

    // Spin duration 4.2s
    setTimeout(() => {
      clearInterval(tickInterval);
      setIsSpinning(false);
      setWonReward(targetReward);
      sound.playWin();
      onRewardAwarded(targetReward);

      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.5 },
        });
      } catch {
        // ignore
      }
    }, 4200);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="crystal-card w-full max-w-sm rounded-3xl border-2 border-yellow-500/40 p-5 flex flex-col items-center text-center shadow-[0_0_60px_rgba(234,179,8,0.35)] relative overflow-hidden"
      >
        {/* Animated luxury video background canvas */}
        <canvas ref={bgCanvasRef} className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-80" />

        {/* Close Button */}
        <button
          disabled={isSpinning}
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="crystal-button absolute top-4 right-4 p-1.5 rounded-full text-slate-300 hover:text-white border-white/10 active:scale-95 disabled:opacity-40"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-1.5 text-yellow-400 mb-1">
          <Sparkles className="w-5 h-5 drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]" />
          <h2 className="text-xl font-black tracking-tight text-white">LUCKY PRIZE WHEEL</h2>
        </div>
        
        {isDailySpinAvailable ? (
          <div className="px-3 py-1 mb-3 rounded-full bg-gradient-to-r from-yellow-500/30 to-amber-500/30 border border-yellow-400/60 text-yellow-300 text-[11px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_12px_rgba(250,204,21,0.4)] animate-pulse">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Today's Free Daily Spin Ready!</span>
          </div>
        ) : (
          <p className="text-xs text-slate-300 mb-4">
            Spin to win coins, hints, undos & powerups!
          </p>
        )}

        {/* Wheel Canvas Container with Top Pointer Needle */}
        <div className="relative my-2 flex items-center justify-center">
          {/* Top Indicator Needle */}
          <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">
            <div className="w-4 h-6 bg-gradient-to-b from-yellow-200 via-yellow-400 to-amber-500 rounded-b-md shadow-md border-2 border-white" />
            <div className="w-0 h-0 border-x-6 border-x-transparent border-t-8 border-t-amber-500 -mt-0.5" />
          </div>

          {/* Rotating Canvas Wheel */}
          <div
            style={{
              transform: `rotate(${currentRotation}deg)`,
              transition: isSpinning ? 'transform 4.2s cubic-bezier(0.12, 0.8, 0.2, 1)' : 'none',
            }}
            className="w-[280px] h-[280px] rounded-full overflow-hidden shadow-[0_0_35px_rgba(250,204,21,0.35)] ring-4 ring-yellow-500/40"
          >
            <canvas ref={canvasRef} className="w-full h-full" />
          </div>
        </div>

        {/* Reward Popup */}
        {wonReward && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="my-3 px-4 py-2 rounded-2xl bg-amber-500/20 border border-yellow-400/60 text-yellow-300 flex items-center gap-2 shadow-[0_0_15px_rgba(250,204,21,0.4)]"
          >
            <Trophy className="w-5 h-5 text-yellow-400 animate-bounce drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]" />
            <span className="text-sm font-black">
              You Won: {wonReward.label}!
            </span>
          </motion.div>
        )}

        {/* Spin Button */}
        <div className="w-full mt-4 flex flex-col items-center gap-2">
          <button
            disabled={isSpinning || (freeSpins <= 0 && coins < 50)}
            onClick={handleSpin}
            className={`w-full py-3.5 px-6 rounded-2xl font-black text-sm tracking-wide uppercase transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 ${
              isSpinning || (freeSpins <= 0 && coins < 50)
                ? 'bg-slate-900 border border-white/10 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 text-slate-950 shadow-[0_0_25px_rgba(234,179,8,0.6)] hover:brightness-110 border border-yellow-200'
            }`}
          >
            {isSpinning ? (
              <span className="animate-pulse">Spinning...</span>
            ) : freeSpins > 0 ? (
              <>
                <Sparkles className="w-4 h-4" />
                <span>FREE SPIN ({freeSpins})</span>
              </>
            ) : (
              <>
                <Coins className="w-4 h-4" />
                <span>SPIN (50 Coins)</span>
              </>
            )}
          </button>

          {freeSpins <= 0 && coins < 50 && (
            <span className="text-[11px] text-rose-400 font-bold">
              Need 50 Coins to spin
            </span>
          )}

          {/* Rewarded Ad Option for Free Spin */}
          {onWatchRewardedSpin && !isSpinning && (
            <button
              onClick={() => {
                sound.playClick();
                onWatchRewardedSpin();
              }}
              className="w-full py-2.5 px-4 rounded-2xl bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-500/50 text-emerald-300 font-black text-xs flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md mt-1"
            >
              <Tv className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>Watch Ad for +1 Free Spin</span>
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
