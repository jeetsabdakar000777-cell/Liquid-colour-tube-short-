import React, { useEffect } from 'react';
import { admob } from '../utils/admob';

interface AdMobBannerProps {
  className?: string;
}

export const AdMobBanner: React.FC<AdMobBannerProps> = ({ className = '' }) => {
  useEffect(() => {
    // Triggers real Google Mobile Ads Banner on native platform
    admob.showBanner().catch((err) => {
      console.warn('[AdMob] Banner display note:', err);
    });

    return () => {
      admob.hideBanner().catch(() => {});
    };
  }, []);

  // Preserves intended layout spacing for real Google Mobile Ads bottom banner
  return (
    <div
      className={`w-full flex items-center justify-center select-none z-10 shrink-0 pointer-events-none transition-all ${className}`}
      style={{ minHeight: '50px', height: '50px' }}
      aria-hidden="true"
    />
  );
};
