import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Check, Lock, Coins, Sparkles, Image, FlaskConical, Droplets, Tv, Play, Video, Eye } from 'lucide-react';
import { LOCATIONS, TUBE_THEMES, LIQUID_THEMES } from '../utils/shopData';
import { sound } from '../utils/audio';
import { AdMobBanner } from './AdMobBanner';
import { MiniBackgroundPreview } from './MiniBackgroundPreview';

interface ShopModalProps {
  coins: number;
  equippedLocation: string;
  equippedTube: string;
  equippedLiquid: string;
  unlockedLocations: string[];
  unlockedTubes: string[];
  unlockedLiquids: string[];
  onClose: () => void;
  onEquipLocation: (id: string) => void;
  onEquipTube: (id: string) => void;
  onEquipLiquid: (id: string) => void;
  onBuyItem: (type: 'location' | 'tube' | 'liquid', id: string, price: number) => boolean;
  onWatchRewardedCoins?: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  coins,
  equippedLocation,
  equippedTube,
  equippedLiquid,
  unlockedLocations,
  unlockedTubes,
  unlockedLiquids,
  onClose,
  onEquipLocation,
  onEquipTube,
  onEquipLiquid,
  onBuyItem,
  onWatchRewardedCoins,
}) => {
  const [activeTab, setActiveTab] = useState<'locations' | 'tubes' | 'liquids'>('locations');

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-2 sm:p-4 select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="crystal-card w-full max-w-lg h-[92vh] max-h-[720px] rounded-3xl p-3 sm:p-5 flex flex-col shadow-[0_0_60px_rgba(0,0,0,0.8)] relative overflow-hidden border border-cyan-500/30"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]" />
            <div>
              <h2 className="text-xl font-black text-white tracking-wide leading-none">THEME SHOP</h2>
              <p className="text-[11px] font-bold text-cyan-300">Choose Backgrounds, Tubes & Liquids</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Coins Balance */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/20 border border-amber-500/50 text-yellow-400 text-xs font-black shadow-[0_0_10px_rgba(250,204,21,0.3)]">
              <Coins className="w-4 h-4" />
              <span>{coins.toLocaleString()}</span>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="crystal-button p-2 rounded-full text-slate-300 hover:text-white border-white/10 active:scale-95 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs - clearly labeled */}
        <div className="grid grid-cols-3 gap-2 my-3 p-1.5 rounded-2xl bg-slate-950/80 border border-white/15 shadow-inner shrink-0">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('locations');
            }}
            className={`py-2.5 px-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'locations'
                ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-[0_0_18px_rgba(6,182,212,0.6)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>Backgrounds (28)</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('tubes');
            }}
            className={`py-2.5 px-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'tubes'
                ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-[0_0_18px_rgba(6,182,212,0.6)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FlaskConical className="w-4 h-4" />
            <span>Tubes</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('liquids');
            }}
            className={`py-2.5 px-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'liquids'
                ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-[0_0_18px_rgba(6,182,212,0.6)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Droplets className="w-4 h-4" />
            <span>Liquids</span>
          </button>
        </div>

        {/* Scrollable Items List */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-3 custom-scrollbar">
          {/* Rewarded Video Ad Bonus Coins Card */}
          {onWatchRewardedCoins && (
            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-amber-950/60 border border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)] flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0">
                  <Tv className="w-5 h-5 text-emerald-400 animate-pulse" />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-black text-white flex items-center gap-1.5">
                    Free Coins Video
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-500 text-slate-950 uppercase">
                      AdMob
                    </span>
                  </h4>
                  <p className="text-[11px] text-emerald-300 font-semibold">
                    Watch a video to receive +200 free coins
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  sound.playClick();
                  onWatchRewardedCoins();
                }}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all shrink-0 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-slate-950" />
                <span>+200</span>
              </button>
            </div>
          )}

          {/* LOCATIONS / BACKGROUNDS TAB */}
          {activeTab === 'locations' && (
            <div className="space-y-3">
              <div className="px-2 py-1.5 rounded-xl bg-slate-900/80 border border-cyan-500/30 flex items-center justify-between text-xs text-slate-300">
                <span className="flex items-center gap-1.5 text-cyan-300 font-bold">
                  <Video className="w-4 h-4 text-cyan-400" />
                  28 Live Animated 60FPS Themes
                </span>
                <span className="text-[11px] font-bold text-slate-300">
                  {unlockedLocations.length} / {LOCATIONS.length} Owned
                </span>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                {LOCATIONS.map((loc) => {
                  const isUnlocked = unlockedLocations.includes(loc.id) || loc.price === 0;
                  const isEquipped = equippedLocation === loc.id;
                  const canAfford = coins >= loc.price;

                  return (
                    <div
                      key={loc.id}
                      className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        isEquipped
                          ? 'bg-cyan-950/60 border-cyan-400 shadow-[0_0_22px_rgba(6,182,212,0.35)] ring-1 ring-cyan-400/50'
                          : 'bg-slate-800/70 border-slate-700/70 hover:border-slate-500'
                      }`}
                    >
                      {/* Live Animated Canvas Preview */}
                      <div className="relative shrink-0 overflow-hidden rounded-xl bg-slate-950 border border-white/20 shadow-md">
                        <MiniBackgroundPreview
                          themeId={loc.id}
                          className={`w-16 h-16 rounded-xl bg-gradient-to-tr ${loc.bgGradient}`}
                        />
                        {isEquipped && (
                          <div className="absolute top-1 right-1 px-1 py-0.5 rounded bg-cyan-500 text-slate-950 text-[8px] font-black uppercase">
                            Equipped
                          </div>
                        )}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="text-sm font-black text-white truncate">
                            {loc.name}
                          </h4>
                          {loc.price === 0 && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 uppercase">
                              100% Free
                            </span>
                          )}
                          {isEquipped && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-cyan-500 text-slate-950 uppercase">
                              Selected
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-300 line-clamp-2 mt-0.5 leading-snug">
                          {loc.description}
                        </p>
                      </div>

                      {/* Action Button */}
                      {isEquipped ? (
                        <div className="px-3.5 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 text-xs font-black flex items-center gap-1.5 shrink-0 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                          <Check className="w-4 h-4" />
                          <span>Active</span>
                        </div>
                      ) : isUnlocked ? (
                        <button
                          onClick={() => {
                            sound.playClick();
                            onEquipLocation(loc.id);
                          }}
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-slate-700 to-slate-600 hover:from-cyan-600 hover:to-blue-600 text-white text-xs font-black active:scale-95 transition-all shrink-0 cursor-pointer shadow border border-white/10"
                        >
                          Select & Use
                        </button>
                      ) : (
                        <button
                          disabled={!canAfford}
                          onClick={() => {
                            const ok = onBuyItem('location', loc.id, loc.price);
                            if (ok) {
                              sound.playUnlock();
                              onEquipLocation(loc.id);
                            } else {
                              sound.playError();
                            }
                          }}
                          className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all active:scale-95 shrink-0 ${
                            canAfford
                              ? 'bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 shadow-[0_0_12px_rgba(251,191,36,0.5)] cursor-pointer'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                          }`}
                        >
                          <Coins className="w-3.5 h-3.5" />
                          <span>{loc.price.toLocaleString()}</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TUBES TAB */}
          {activeTab === 'tubes' &&
            TUBE_THEMES.map((tube) => {
              const isUnlocked = unlockedTubes.includes(tube.id);
              const isEquipped = equippedTube === tube.id;
              const canAfford = coins >= tube.price;

              return (
                <div
                  key={tube.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isEquipped
                      ? 'bg-cyan-950/40 border-cyan-500/80 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                      : 'bg-slate-800/60 border-slate-700/60 hover:border-slate-600'
                  }`}
                >
                  {/* Preview Tube mini render */}
                  <div className="w-14 h-14 rounded-xl bg-slate-950/80 border border-slate-800 shrink-0 flex items-center justify-center">
                    <div
                      className={`w-6 h-10 rounded-b-xl border ${tube.borderStyle} bg-gradient-to-b ${tube.glassGradient} relative overflow-hidden`}
                    >
                      <div className="absolute bottom-0 inset-x-0 h-4 bg-gradient-to-t from-cyan-500 to-blue-500 rounded-b-xl" />
                      <div className={`absolute top-0 inset-x-0 h-1 ${tube.rimColor}`} />
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-black text-white truncate">
                        {tube.name}
                      </h4>
                      {isEquipped && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-cyan-500 text-slate-950 uppercase">
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                      {tube.description}
                    </p>
                  </div>

                  {/* Action Button */}
                  {isEquipped ? (
                    <div className="px-3 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 text-xs font-black flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Used</span>
                    </div>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => {
                        sound.playClick();
                        onEquipTube(tube.id);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold active:scale-95 transition-all"
                    >
                      Equip
                    </button>
                  ) : (
                    <button
                      disabled={!canAfford}
                      onClick={() => {
                        const ok = onBuyItem('tube', tube.id, tube.price);
                        if (ok) {
                          sound.playUnlock();
                          onEquipTube(tube.id);
                        } else {
                          sound.playError();
                        }
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1 transition-all active:scale-95 ${
                        canAfford
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5" />
                      <span>{tube.price}</span>
                    </button>
                  )}
                </div>
              );
            })}

          {/* LIQUIDS TAB */}
          {activeTab === 'liquids' &&
            LIQUID_THEMES.map((liq) => {
              const isUnlocked = unlockedLiquids.includes(liq.id);
              const isEquipped = equippedLiquid === liq.id;
              const canAfford = coins >= liq.price;

              return (
                <div
                  key={liq.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isEquipped
                      ? 'bg-cyan-950/40 border-cyan-500/80 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                      : 'bg-slate-800/60 border-slate-700/60 hover:border-slate-600'
                  }`}
                >
                  {/* Preview Liquid droplet */}
                  <div className="w-14 h-14 rounded-xl bg-slate-950/80 border border-slate-800 shrink-0 flex items-center justify-center">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-pink-500 via-purple-500 to-cyan-400 shadow-md flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-white animate-spin" />
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-black text-white truncate">
                        {liq.name}
                      </h4>
                      {isEquipped && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-cyan-500 text-slate-950 uppercase">
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                      {liq.description}
                    </p>
                  </div>

                  {/* Action Button */}
                  {isEquipped ? (
                    <div className="px-3 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 text-xs font-black flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Used</span>
                    </div>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => {
                        sound.playClick();
                        onEquipLiquid(liq.id);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold active:scale-95 transition-all"
                    >
                      Equip
                    </button>
                  ) : (
                    <button
                      disabled={!canAfford}
                      onClick={() => {
                        const ok = onBuyItem('liquid', liq.id, liq.price);
                        if (ok) {
                          sound.playUnlock();
                          onEquipLiquid(liq.id);
                        } else {
                          sound.playError();
                        }
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1 transition-all active:scale-95 ${
                        canAfford
                          ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5" />
                      <span>{liq.price}</span>
                    </button>
                  )}
                </div>
              );
            })}
        </div>

        {/* AdMob Adaptive Banner */}
        <AdMobBanner className="pt-2" />
      </motion.div>
    </div>
  );
};
