import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { ColorId, Tube } from '../types/game';
import { LIQUID_COLORS } from '../utils/colors';
import { TubeTheme, LiquidTheme } from '../utils/shopData';
import { Lock, Sparkles, HelpCircle } from 'lucide-react';

interface TubeViewProps {
  tube: Tube;
  index: number;
  isSelected: boolean;
  isHintSource: boolean;
  isHintDest: boolean;
  isInvalid: boolean;
  isCompleted: boolean;
  isPouringSource: boolean;
  isPouringDest: boolean;
  pouringProgress?: number;
  tiltAngle?: number;
  tubeTheme: TubeTheme;
  liquidTheme: LiquidTheme;
  showColorblindSymbols: boolean;
  onSelect: (index: number) => void;
  scale?: number;
}

export const TubeView: React.FC<TubeViewProps> = ({
  tube,
  index,
  isSelected,
  isHintSource,
  isHintDest,
  isInvalid,
  isCompleted,
  isPouringSource,
  isPouringDest,
  tiltAngle = 0,
  tubeTheme,
  liquidTheme,
  showColorblindSymbols,
  onSelect,
  scale = 1,
}) => {
  const { layers, isLocked, hiddenCount = 0 } = tube;
  const isFullAndUniform = layers.length === 4 && layers.every((c) => c === layers[0]);

  // Scaled dimensions
  const tubeWidth = Math.round(52 * scale);
  const tubeHeight = Math.round(180 * scale);
  const layerHeight = Math.round((tubeHeight - 16) / 4); // 4 layers fit with 16px headspace rim

  // Natural spout pivot origin
  const rotateOrigin = tiltAngle > 0 ? 'top right' : tiltAngle < 0 ? 'top left' : 'center top';

  // Settling state after receiving liquid or after pouring into this tube concludes
  const [isSettling, setIsSettling] = useState(false);
  const prevPouringDest = useRef(isPouringDest);
  const prevLayerCount = useRef(layers.length);

  useEffect(() => {
    if (
      (prevPouringDest.current && !isPouringDest) ||
      layers.length > prevLayerCount.current
    ) {
      setIsSettling(true);
      const timer = setTimeout(() => setIsSettling(false), 750);
      return () => clearTimeout(timer);
    }
    prevPouringDest.current = isPouringDest;
    prevLayerCount.current = layers.length;
  }, [isPouringDest, layers.length]);

  // Build layers ordered from TOP (surface) to BOTTOM (base)
  // layers[0] is at the bottom of the tube; layers[layers.length - 1] is at the top surface
  const layersFromTopToBottom = layers
    .map((colorId, originalIdx) => ({ colorId, originalIdx }))
    .reverse();

  // Bottom layer color for realistic pedestal caustics
  const bottomColorId = layers.length > 0 ? layers[0] : null;
  const bottomColorInfo = bottomColorId ? LIQUID_COLORS[bottomColorId] : null;

  return (
    <div
      className={`relative flex flex-col items-center select-none touch-manipulation cursor-pointer group ${
        isPouringSource ? 'z-50' : isSelected ? 'z-30' : 'z-10'
      }`}
      onClick={() => onSelect(index)}
      style={{
        width: `${tubeWidth + 10}px`,
        height: `${tubeHeight + 28}px`,
      }}
    >
      {/* Hint Indicator Arrow */}
      {isHintSource && (
        <motion.div
          initial={{ y: -6, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ repeat: Infinity, repeatType: 'reverse', duration: 0.5, ease: 'easeInOut' }}
          className="absolute -top-7 text-yellow-300 z-40 flex flex-col items-center drop-shadow-[0_0_10px_rgba(253,224,71,0.9)]"
        >
          <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-yellow-300 to-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full shadow-lg border border-yellow-100">
            Pour
          </span>
          <span className="text-xs font-black -mt-0.5 text-yellow-300">▼</span>
        </motion.div>
      )}

      {isHintDest && (
        <motion.div
          initial={{ y: -6, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ repeat: Infinity, repeatType: 'reverse', duration: 0.5, ease: 'easeInOut' }}
          className="absolute -top-7 text-emerald-300 z-40 flex flex-col items-center drop-shadow-[0_0_10px_rgba(52,211,153,0.9)]"
        >
          <span className="text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-emerald-300 to-teal-400 text-slate-950 px-2.5 py-0.5 rounded-full shadow-lg border border-emerald-100">
            Here
          </span>
          <span className="text-xs font-black -mt-0.5 text-emerald-300">▼</span>
        </motion.div>
      )}

      {/* Main Glass Test Tube Vessel */}
      <motion.div
        id={`tube-${index}`}
        animate={{
          y: isPouringSource ? -44 : isSelected ? -20 : isPouringDest ? [0, 3, -1, 0] : 0,
          x: isPouringSource ? (tiltAngle > 0 ? 18 : -18) : isInvalid ? [-6, 6, -5, 5, -2, 2, 0] : 0,
          rotate: tiltAngle,
          scale: isPouringSource ? 1.06 : isSelected ? 1.04 : 1,
        }}
        transition={{
          y: isPouringDest
            ? { duration: 0.35, ease: 'easeOut' }
            : { type: 'spring', stiffness: 380, damping: 25 },
          x: isPouringSource
            ? { type: 'spring', stiffness: 350, damping: 26 }
            : { duration: 0.35, ease: 'easeInOut' },
          rotate: { type: 'spring', stiffness: 320, damping: 24 },
          scale: { duration: 0.18 },
        }}
        style={{
          transformOrigin: rotateOrigin,
          width: `${tubeWidth}px`,
          height: `${tubeHeight}px`,
          willChange: 'transform',
        }}
        className={`relative flex flex-col justify-end items-center rounded-b-[28px] rounded-t-[6px] transform-gpu transition-shadow duration-200 ${
          isSelected
            ? 'shadow-[0_4px_16px_rgba(6,182,212,0.4)] ring-2 ring-cyan-400 ring-offset-2 ring-offset-slate-950/80'
            : isHintSource
            ? 'shadow-[0_4px_14px_rgba(250,204,21,0.4)] ring-2 ring-yellow-400'
            : isHintDest
            ? 'shadow-[0_4px_14px_rgba(52,211,153,0.4)] ring-2 ring-emerald-400'
            : isFullAndUniform
            ? 'shadow-[0_4px_12px_rgba(6,182,212,0.25)] ring-1 ring-cyan-400/40'
            : 'shadow-[0_6px_16px_rgba(0,0,0,0.35)]'
        }`}
      >
        {/* Precise Coordinate Markers for PourStream Attachment */}
        <div id={`tube-spout-left-${index}`} className="absolute -top-1 left-0 w-2 h-2 pointer-events-none opacity-0" />
        <div id={`tube-spout-right-${index}`} className="absolute -top-1 right-0 w-2 h-2 pointer-events-none opacity-0" />
        <div id={`tube-mouth-${index}`} className="absolute -top-1 left-1/2 -translate-x-1/2 w-4 h-2 pointer-events-none opacity-0" />

        {/* Top Rim Glass Lip */}
        <div
          className="absolute -top-2 left-1/2 -translate-x-1/2 rounded-full z-30 pointer-events-none"
          style={{
            width: `${tubeWidth + 4}px`,
            height: '8px',
            border: '1.5px solid rgba(56, 189, 248, 0.45)',
            background: 'rgba(255, 255, 255, 0.08)',
          }}
        >
          {/* Subtle rim highlight */}
          <div className="absolute top-0.5 left-2 w-2.5 h-0.5 rounded-full bg-white/60 pointer-events-none" />
        </div>

        {/* Outer Cylinder: Clear Transparent Glass Walls & Subtle Highlights */}
        <div
          className="absolute inset-0 rounded-b-[28px] rounded-t-[6px] border-[1.5px] border-cyan-400/35 pointer-events-none z-20 overflow-hidden bg-transparent"
        >
          {/* Subtle Thin Specular Streak (Left) */}
          <div className="absolute left-1 top-2.5 bottom-6 w-[1.5px] rounded-full bg-gradient-to-b from-white/45 via-white/20 to-transparent pointer-events-none" />

          {/* Subtle Thin Reflection Line (Right) */}
          <div className="absolute right-1 top-2.5 bottom-7 w-[1px] rounded-full bg-gradient-to-b from-cyan-300/20 via-white/10 to-transparent pointer-events-none" />

          {/* Clean Curved Glass Bottom Outline */}
          <div className="absolute bottom-0 inset-x-0 h-3 rounded-b-[26px] border-b-[1.5px] border-cyan-300/40 pointer-events-none" />
        </div>

        {/* Interior Fluid Chamber */}
        <div className="relative w-full h-full rounded-b-[26px] overflow-hidden flex flex-col justify-end px-[2px] pb-[3px] pt-[2px] z-10 bg-transparent">
          {/* Render Liquid Layers from TOP to BOTTOM */}
          {layersFromTopToBottom.map(({ colorId, originalIdx }) => {
            const colorInfo = LIQUID_COLORS[colorId] || LIQUID_COLORS.blue;
            const isTopLayer = originalIdx === layers.length - 1; // Top surface of fluid column
            const isBottomLayer = originalIdx === 0; // Resting on curved tube bottom
            const isHidden = hiddenCount > originalIdx;

            // Check if layer directly BELOW this one has the same color (merge smoothly)
            const belowColor = originalIdx > 0 ? layers[originalIdx - 1] : null;
            const isSameAsBelow = belowColor === colorId && !isHidden;

            // Dynamic wave duration & animation style
            const waveDuration = isPouringDest ? 0.28 : isSettling ? 0.8 : 2.0;

            return (
              <div
                key={`${originalIdx}-${colorId}`}
                className={`relative w-full overflow-hidden transition-[height,opacity] duration-250 ease-out ${
                  isBottomLayer ? 'rounded-b-[24px]' : ''
                }`}
                style={{
                  height: `${layerHeight}px`,
                  backgroundColor: isHidden ? '#334155' : colorInfo.baseHex,
                  backgroundImage: isHidden
                    ? 'linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%)'
                    : `linear-gradient(180deg, ${colorInfo.baseHex} 0%, ${colorInfo.baseHex} 82%, ${colorInfo.bottomShadow} 100%)`,
                }}
              >
                {/* Wavy Animated Meniscus at top of top liquid layer */}
                {isTopLayer && !isHidden && (
                  <div
                    className="tube-liquid-surface absolute -top-3 left-0 w-full h-6 z-10 pointer-events-none overflow-visible"
                    style={{ animationDuration: `${waveDuration}s` }}
                  >
                    <svg
                      className="w-full h-full overflow-visible"
                      viewBox="0 0 100 24"
                      preserveAspectRatio="none"
                    >
                      {/* Primary Wavy Liquid Body */}
                      <motion.path
                        animate={{
                          d: isPouringDest
                            ? [
                                'M 0 12 Q 25 3, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 21, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 3, 50 12 T 100 12 L 100 24 L 0 24 Z',
                              ]
                            : isSettling
                            ? [
                                'M 0 12 Q 25 5, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 18, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 8, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 15, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 25 12, 50 12 T 100 12 L 100 24 L 0 24 Z',
                              ]
                            : isPouringSource && tiltAngle !== 0
                            ? tiltAngle > 0
                              ? 'M 0 18 Q 50 14, 100 6 L 100 24 L 0 24 Z'
                              : 'M 0 6 Q 50 14, 100 18 L 100 24 L 0 24 Z'
                            : [
                                'M 0 12 Q 30 7, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 30 17, 50 12 T 100 12 L 100 24 L 0 24 Z',
                                'M 0 12 Q 30 7, 50 12 T 100 12 L 100 24 L 0 24 Z',
                              ],
                        }}
                        transition={{
                          repeat: isSettling || (isPouringSource && tiltAngle !== 0) ? 0 : Infinity,
                          duration: waveDuration,
                          ease: isSettling ? 'easeOut' : 'easeInOut',
                        }}
                        fill={colorInfo.baseHex}
                      />

                      {/* Clean Light Meniscus Edge */}
                      <motion.path
                        animate={{
                          d: isPouringDest
                            ? [
                                'M 0 12 Q 25 3, 50 12 T 100 12',
                                'M 0 12 Q 25 21, 50 12 T 100 12',
                                'M 0 12 Q 25 3, 50 12 T 100 12',
                              ]
                            : isSettling
                            ? [
                                'M 0 12 Q 25 5, 50 12 T 100 12',
                                'M 0 12 Q 25 18, 50 12 T 100 12',
                                'M 0 12 Q 25 8, 50 12 T 100 12',
                                'M 0 12 Q 25 15, 50 12 T 100 12',
                                'M 0 12 Q 25 12, 50 12 T 100 12',
                              ]
                            : isPouringSource && tiltAngle !== 0
                            ? tiltAngle > 0
                              ? 'M 0 18 Q 50 14, 100 6'
                              : 'M 0 6 Q 50 14, 100 18'
                            : [
                                'M 0 12 Q 30 7, 50 12 T 100 12',
                                'M 0 12 Q 30 17, 50 12 T 100 12',
                                'M 0 12 Q 30 7, 50 12 T 100 12',
                              ],
                        }}
                        transition={{
                          repeat: isSettling || (isPouringSource && tiltAngle !== 0) ? 0 : Infinity,
                          duration: waveDuration,
                          ease: isSettling ? 'easeOut' : 'easeInOut',
                        }}
                        fill="none"
                        stroke="rgba(255, 255, 255, 0.45)"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>
                )}

                {/* Subtle Natural Liquid Cylinder Highlight (Light glossy reflection, no whiteout) */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: 'linear-gradient(90deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0.03) 14%, transparent 32%, rgba(0,0,0,0.14) 100%)',
                  }}
                />

                {/* Hidden Mystery Layer Icon */}
                {isHidden && (
                  <div className="absolute inset-0 flex items-center justify-center text-slate-400">
                    <HelpCircle className="w-4 h-4 animate-pulse" />
                  </div>
                )}

                {/* Colorblind Accessible Symbol */}
                {showColorblindSymbols && !isHidden && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
                    <span className="text-[11px] font-black text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] bg-black/40 border border-white/20 rounded px-1">
                      {colorInfo.symbol}
                    </span>
                  </div>
                )}

                {/* Clear Boundary Separator Line at BOTTOM of layer (Only if DIFFERENT color from layer below) */}
                {!isBottomLayer && !isSameAsBelow && (
                  <div className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-black/35 border-b border-white/25 z-10 pointer-events-none" />
                )}
              </div>
            );
          })}

          {/* Empty Tube: Clear Transparent Glass */}
          {layers.length === 0 && null}
        </div>

        {/* Dynamic Water Splash Particles when liquid drops in */}
        {isPouringDest && (
          <div className="absolute top-[12%] left-1/2 -translate-x-1/2 w-10 h-8 pointer-events-none z-30 flex justify-center items-center">
            {/* Impact Center Flare */}
            <motion.div
              initial={{ scale: 0.6, opacity: 0.9 }}
              animate={{ scale: [0.8, 1.4, 0.9], opacity: [0.9, 1, 0.3] }}
              transition={{ repeat: Infinity, duration: 0.28, ease: 'easeOut' }}
              className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_#fff]"
            />
            {/* Splash Droplets jumping up */}
            <motion.div
              animate={{ y: [-4, -14, -2], x: [-6, -10, -12], opacity: [1, 0.8, 0] }}
              transition={{ repeat: Infinity, duration: 0.3, ease: 'easeOut' }}
              className="absolute w-1.5 h-1.5 rounded-full bg-cyan-100 shadow-[0_0_4px_#cffafe]"
            />
            <motion.div
              animate={{ y: [-4, -16, -2], x: [4, 8, 10], opacity: [1, 0.8, 0] }}
              transition={{ repeat: Infinity, duration: 0.26, ease: 'easeOut', delay: 0.05 }}
              className="absolute w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_4px_#fff]"
            />
          </div>
        )}

        {/* Settling Ripples after Pour Finishes */}
        {isSettling && !isPouringDest && (
          <motion.div
            initial={{ opacity: 0.8, scale: 0.8 }}
            animate={{ opacity: 0, scale: 1.3 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="absolute top-[20%] left-1/2 -translate-x-1/2 w-6 h-2 rounded-full border border-white/60 pointer-events-none z-30"
          />
        )}

        {/* Tube Complete Sparkle Ring */}
        {isFullAndUniform && isCompleted && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [1, 1.2, 1], opacity: [0.85, 1, 0.85] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            className="absolute -top-3.5 -right-2.5 text-yellow-300 pointer-events-none z-30"
          >
            <Sparkles className="w-5 h-5 drop-shadow-[0_0_8px_rgba(253,224,71,0.95)] fill-yellow-400" />
          </motion.div>
        )}

        {/* Locked Tube Lock Overlay */}
        {isLocked && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-[2px] rounded-b-[30px] rounded-t-[8px] z-30 flex flex-col items-center justify-center p-2 text-center border border-amber-500/50 shadow-inner">
            <Lock className="w-6 h-6 text-amber-400 mb-1 animate-bounce drop-shadow-[0_0_6px_rgba(251,191,36,0.6)]" />
            <span className="text-[10px] font-black text-amber-200 leading-tight uppercase tracking-wider">
              Locked
            </span>
          </div>
        )}
      </motion.div>

      {/* Tube Base Pedestal Shadow */}
      <div
        className="mt-1 rounded-full blur-[1.5px] transition-all duration-300 pointer-events-none"
        style={{
          width: `${tubeWidth * (isSelected ? 0.75 : isPouringSource ? 0.65 : 0.88)}px`,
          height: '4px',
          backgroundColor: 'rgba(0, 0, 0, 0.35)',
          opacity: isPouringSource ? 0.15 : isSelected ? 0.22 : 0.4,
        }}
      />
    </div>
  );
};
