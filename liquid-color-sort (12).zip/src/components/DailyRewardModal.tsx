import React from 'react';
import { motion } from 'motion/react';
import { X, Calendar, Gift, Check, Sparkles, Coins, Lightbulb, RotateCcw } from 'lucide-react';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';

interface DailyRewardModalProps {
  dailyStreak: number;
  canClaim: boolean;
  onClaim: () => void;
  onClose: () => void;
}

const DAILY_REWARDS = [
  { day: 1, label: '100 Coins', icon: 'coins', amount: 100 },
  { day: 2, label: '150 Coins', icon: 'coins', amount: 150 },
  { day: 3, label: '+2 Hints', icon: 'hint', amount: 2 },
  { day: 4, label: '200 Coins', icon: 'coins', amount: 200 },
  { day: 5, label: '+2 Undos', icon: 'undo', amount: 2 },
  { day: 6, label: '300 Coins', icon: 'coins', amount: 300 },
  { day: 7, label: '500 Coins + 2 Spins', icon: 'gift', amount: 500 },
];

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  dailyStreak,
  canClaim,
  onClaim,
  onClose,
}) => {
  const currentDayIndex = dailyStreak % 7;

  const handleClaim = () => {
    sound.playWin();
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }
    onClaim();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="crystal-card w-full max-w-sm rounded-3xl border-purple-500/40 p-5 flex flex-col items-center text-center shadow-[0_0_60px_rgba(168,85,247,0.4)] relative overflow-hidden"
      >
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="crystal-button absolute top-4 right-4 p-1.5 rounded-full text-slate-300 hover:text-white border-white/10 active:scale-95"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-1.5 text-purple-300 mb-1">
          <Calendar className="w-5 h-5 text-purple-400" />
          <h2 className="text-xl font-black tracking-tight text-white">DAILY REWARDS</h2>
        </div>
        <p className="text-xs text-slate-300 mb-4">
          Check in every day to unlock bigger bonus rewards!
        </p>

        {/* 7 Days Grid */}
        <div className="w-full grid grid-cols-4 gap-2 mb-4">
          {DAILY_REWARDS.map((item, idx) => {
            const isCompleted = idx < currentDayIndex;
            const isToday = idx === currentDayIndex;
            const isDay7 = idx === 6;

            return (
              <div
                key={item.day}
                className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center transition-all ${
                  isDay7 ? 'col-span-2 bg-gradient-to-r from-purple-900/80 to-amber-900/80 border-amber-400/60 shadow-[0_0_15px_rgba(245,158,11,0.3)]' : ''
                } ${
                  isCompleted
                    ? 'bg-slate-900/50 border-white/5 opacity-60 text-slate-400'
                    : isToday
                    ? 'bg-gradient-to-b from-purple-600/40 to-slate-900 border-purple-400 ring-2 ring-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)] text-white'
                    : 'bg-slate-950/60 border-white/10 text-slate-300'
                }`}
              >
                <span className="text-[10px] font-black uppercase text-slate-400">
                  Day {item.day}
                </span>

                <div className="my-1">
                  {isCompleted ? (
                    <Check className="w-6 h-6 text-emerald-400" />
                  ) : item.icon === 'coins' ? (
                    <Coins className="w-6 h-6 text-yellow-400 drop-shadow-[0_0_4px_rgba(250,204,21,0.8)]" />
                  ) : item.icon === 'hint' ? (
                    <Lightbulb className="w-6 h-6 text-yellow-300 drop-shadow-[0_0_4px_rgba(253,224,71,0.8)]" />
                  ) : item.icon === 'undo' ? (
                    <RotateCcw className="w-6 h-6 text-cyan-400 drop-shadow-[0_0_4px_rgba(34,211,238,0.8)]" />
                  ) : (
                    <Gift className="w-6 h-6 text-amber-300 animate-bounce drop-shadow-[0_0_8px_rgba(245,158,11,0.8)]" />
                  )}
                </div>

                <span className="text-[10px] font-black text-center leading-tight">
                  {item.label}
                </span>
              </div>
            );
          })}
        </div>

        {/* Claim Button */}
        <button
          disabled={!canClaim}
          onClick={handleClaim}
          className={`w-full py-3.5 px-6 rounded-2xl font-black text-sm tracking-wide uppercase transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 ${
            canClaim
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white shadow-[0_0_25px_rgba(217,70,239,0.6)] border border-purple-300'
              : 'bg-slate-900 border border-white/10 text-slate-500 cursor-not-allowed'
          }`}
        >
          {canClaim ? (
            <>
              <Sparkles className="w-4 h-4" />
              <span>CLAIM REWARD</span>
            </>
          ) : (
            <span>ALREADY CLAIMED TODAY</span>
          )}
        </button>
      </motion.div>
    </div>
  );
};
