import React, { useEffect, useRef } from 'react';

interface Snowflake {
  x: number;
  y: number;
  radius: number;
  speedY: number;
  speedX: number;
  angle: number;
  spin: number;
  opacity: number;
  layer: number; // 0: background (fine), 1: midground (crisp star/disc), 2: foreground (large, soft blur)
  wobbleSpeed: number;
  wobbleDist: number;
  baseX: number;
  glow: boolean;
}

export const SnowyGameBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initFlakes();
    };

    window.addEventListener('resize', handleResize);

    // Generate flakes with 3D depth
    const flakes: Snowflake[] = [];
    const NUM_FLAKES = Math.min(130, Math.floor(width * 0.12) + 40);

    const initFlakes = () => {
      flakes.length = 0;
      for (let i = 0; i < NUM_FLAKES; i++) {
        const layer = Math.random() < 0.25 ? 2 : Math.random() < 0.65 ? 1 : 0;
        let radius = 1.5;
        let speedY = 0.8;
        let opacity = 0.5;

        if (layer === 0) {
          // Background powder
          radius = 0.8 + Math.random() * 1.2;
          speedY = 0.4 + Math.random() * 0.6;
          opacity = 0.25 + Math.random() * 0.35;
        } else if (layer === 1) {
          // Midground crystals
          radius = 1.8 + Math.random() * 2.2;
          speedY = 0.9 + Math.random() * 1.1;
          opacity = 0.6 + Math.random() * 0.35;
        } else {
          // Foreground soft flakes
          radius = 3.5 + Math.random() * 3.5;
          speedY = 1.6 + Math.random() * 1.4;
          opacity = 0.4 + Math.random() * 0.45;
        }

        const startX = Math.random() * width;
        flakes.push({
          x: startX,
          y: Math.random() * height,
          radius,
          speedY,
          speedX: (Math.random() - 0.5) * 0.4,
          angle: Math.random() * Math.PI * 2,
          spin: (Math.random() - 0.5) * 0.03,
          opacity,
          layer,
          wobbleSpeed: 0.015 + Math.random() * 0.03,
          wobbleDist: 20 + Math.random() * 35,
          baseX: startX,
          glow: Math.random() < 0.18,
        });
      }
    };

    initFlakes();

    // Draw crystal snowflake star helper
    const drawCrystalFlake = (
      context: CanvasRenderingContext2D,
      x: number,
      y: number,
      r: number,
      angle: number,
      alpha: number
    ) => {
      context.save();
      context.translate(x, y);
      context.rotate(angle);
      context.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
      context.lineWidth = Math.max(1, r * 0.28);
      context.lineCap = 'round';

      // 6-armed snowflake crystal
      for (let i = 0; i < 6; i++) {
        context.beginPath();
        context.moveTo(0, 0);
        context.lineTo(0, r);
        context.stroke();

        // Branchlets
        if (r > 3) {
          context.beginPath();
          context.moveTo(0, r * 0.55);
          context.lineTo(r * 0.25, r * 0.75);
          context.moveTo(0, r * 0.55);
          context.lineTo(-r * 0.25, r * 0.75);
          context.stroke();
        }

        context.rotate(Math.PI / 3);
      }

      // Center bright core
      context.beginPath();
      context.arc(0, 0, r * 0.25, 0, Math.PI * 2);
      context.fillStyle = `rgba(255, 255, 255, ${Math.min(1, alpha + 0.3)})`;
      context.fill();

      context.restore();
    };

    let time = 0;

    const render = () => {
      time += 0.018;
      ctx.clearRect(0, 0, width, height);

      // 1. Dynamic Video-like Aurora Borealis Ambient Glow
      const auroraGradient = ctx.createLinearGradient(0, 0, width, height * 0.6);
      const auroraWave = Math.sin(time * 0.8) * 0.1 + 0.2;
      const auroraWave2 = Math.cos(time * 0.6) * 0.08 + 0.15;

      auroraGradient.addColorStop(0, `rgba(6, 182, 212, ${auroraWave})`);
      auroraGradient.addColorStop(0.4, `rgba(59, 130, 246, ${auroraWave2})`);
      auroraGradient.addColorStop(0.8, `rgba(168, 85, 247, ${auroraWave * 0.6})`);
      auroraGradient.addColorStop(1, 'rgba(15, 23, 42, 0)');

      ctx.fillStyle = auroraGradient;
      ctx.fillRect(0, 0, width, height * 0.75);

      // Aurora flowing wave curve in sky
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0, height * 0.15);
      for (let x = 0; x <= width; x += 30) {
        const yOffset =
          Math.sin(x * 0.004 + time * 0.9) * 28 +
          Math.cos(x * 0.008 - time * 0.6) * 18;
        ctx.lineTo(x, height * 0.18 + yOffset);
      }
      ctx.lineTo(width, 0);
      ctx.lineTo(0, 0);
      ctx.closePath();
      const skyRibbon = ctx.createLinearGradient(0, 0, width, height * 0.3);
      skyRibbon.addColorStop(0, 'rgba(56, 189, 248, 0.22)');
      skyRibbon.addColorStop(0.5, 'rgba(129, 140, 248, 0.18)');
      skyRibbon.addColorStop(1, 'transparent');
      ctx.fillStyle = skyRibbon;
      ctx.fill();
      ctx.restore();

      // 2. Distant Snow Mountain Silhouettes (Layered Depth)
      ctx.save();
      // Back Mountain Ridge
      ctx.beginPath();
      ctx.moveTo(0, height);
      ctx.lineTo(0, height * 0.78);
      ctx.lineTo(width * 0.22, height * 0.70);
      ctx.lineTo(width * 0.45, height * 0.75);
      ctx.lineTo(width * 0.72, height * 0.68);
      ctx.lineTo(width, height * 0.76);
      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.fillStyle = 'rgba(15, 23, 42, 0.45)';
      ctx.fill();

      // Front Mountain Ridge
      ctx.beginPath();
      ctx.moveTo(0, height);
      ctx.lineTo(0, height * 0.86);
      ctx.lineTo(width * 0.32, height * 0.80);
      ctx.lineTo(width * 0.60, height * 0.84);
      ctx.lineTo(width * 0.88, height * 0.79);
      ctx.lineTo(width, height * 0.85);
      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.fillStyle = 'rgba(10, 15, 30, 0.6)';
      ctx.fill();
      ctx.restore();

      // 3. Falling Snowflakes Physics Loop
      const windForce = Math.sin(time * 0.5) * 0.8 + 0.3; // natural gentle wind drift

      for (let i = 0; i < flakes.length; i++) {
        const flake = flakes[i];

        // Update movement
        flake.y += flake.speedY;
        flake.angle += flake.spin;
        flake.x =
          flake.baseX +
          Math.sin(time * flake.wobbleSpeed * 60 + i) * flake.wobbleDist +
          windForce * 12;

        // Wrap around boundaries
        if (flake.y > height + 15) {
          flake.y = -10;
          flake.baseX = Math.random() * width;
          flake.x = flake.baseX;
        }
        if (flake.x > width + 20) flake.baseX = -20;
        if (flake.x < -20) flake.baseX = width + 20;

        // Render Flake based on depth layer
        if (flake.layer === 0) {
          // Fine powder dust
          ctx.beginPath();
          ctx.arc(flake.x, flake.y, flake.radius, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(224, 242, 254, ${flake.opacity})`;
          ctx.fill();
        } else if (flake.layer === 1) {
          // Crisp geometric crystal snowflake or star
          if (flake.radius > 2.5) {
            drawCrystalFlake(ctx, flake.x, flake.y, flake.radius * 1.6, flake.angle, flake.opacity);
          } else {
            ctx.beginPath();
            ctx.arc(flake.x, flake.y, flake.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 255, 255, ${flake.opacity})`;
            ctx.fill();
            if (flake.glow) {
              ctx.shadowColor = '#38bdf8';
              ctx.shadowBlur = 6;
              ctx.fill();
              ctx.shadowBlur = 0;
            }
          }
        } else {
          // Foreground large soft bokeh flake
          const grad = ctx.createRadialGradient(
            flake.x,
            flake.y,
            0,
            flake.x,
            flake.y,
            flake.radius
          );
          grad.addColorStop(0, `rgba(255, 255, 255, ${flake.opacity * 0.95})`);
          grad.addColorStop(0.5, `rgba(224, 242, 254, ${flake.opacity * 0.5})`);
          grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

          ctx.beginPath();
          ctx.arc(flake.x, flake.y, flake.radius, 0, Math.PI * 2);
          ctx.fillStyle = grad;
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
      style={{ filter: 'drop-shadow(0 0 10px rgba(6,182,212,0.15))' }}
    />
  );
};
