import React, { useEffect, useRef } from 'react';

interface MiniBackgroundPreviewProps {
  themeId: string;
  className?: string;
}

export const MiniBackgroundPreview: React.FC<MiniBackgroundPreviewProps> = ({
  themeId,
  className = 'w-20 h-20 rounded-xl',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animId: number;
    const width = (canvas.width = 90);
    const height = (canvas.height = 90);

    let t = 0;
    const particles = Array.from({ length: 14 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.8,
      vy: 0.5 + Math.random() * 1.0,
      size: 1.5 + Math.random() * 2.5,
      color: '#ffffff',
    }));

    // Setup colors
    particles.forEach((p) => {
      if (themeId === 'sakura_bloom') p.color = '#f472b6';
      else if (themeId === 'cyber_matrix') p.color = '#22c55e';
      else if (themeId === 'magic_fireflies') p.color = '#fef08a';
      else if (themeId === 'cosmic_galaxy') p.color = '#c084fc';
      else if (themeId === 'ocean_reef') {
        p.color = '#38bdf8';
        p.vy = -0.8;
      } else if (themeId.includes('volcano') || themeId.includes('dragon')) {
        p.color = '#f97316';
        p.vy = -1.2;
      } else if (themeId === 'golden_palace') p.color = '#fbbf24';
      else if (themeId === 'neon_synthwave') p.color = '#e879f9';
      else p.color = '#ffffff';
    });

    const draw = () => {
      t += 0.03;
      ctx.clearRect(0, 0, width, height);

      // Theme-specific background effects
      if (themeId.includes('aurora')) {
        const grad = ctx.createLinearGradient(0, 0, width, height * 0.8);
        grad.addColorStop(
          0,
          themeId === 'emerald_aurora'
            ? 'rgba(16, 185, 129, 0.45)'
            : 'rgba(6, 182, 212, 0.45)'
        );
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
      } else if (themeId === 'neon_synthwave') {
        // Sun on horizon
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(width / 2, height * 0.6, 18, 0, Math.PI * 2);
        ctx.fill();
        // Grid lines
        ctx.strokeStyle = 'rgba(217,70,239,0.4)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, height * 0.65);
        ctx.lineTo(width, height * 0.65);
        ctx.stroke();
      } else if (themeId === 'steampunk_clock') {
        // Little rotating gear
        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.rotate(t * 0.8);
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.5)';
        ctx.lineWidth = 2;
        ctx.strokeRect(-12, -12, 24, 24);
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      } else if (themeId === 'quantum_realm') {
        // Atom ring
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.5)';
        ctx.beginPath();
        ctx.ellipse(width / 2, height / 2, 24, 10, t, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Draw active particles
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.y > height + 5) p.y = -5;
        if (p.y < -5) p.y = height + 5;
        if (p.x > width + 5) p.x = -5;
        if (p.x < -5) p.x = width + 5;

        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      animId = requestAnimationFrame(draw);
    };

    draw();

    return () => cancelAnimationFrame(animId);
  }, [themeId]);

  return (
    <canvas
      ref={canvasRef}
      className={`relative overflow-hidden border border-white/20 shadow-inner shrink-0 ${className}`}
    />
  );
};
