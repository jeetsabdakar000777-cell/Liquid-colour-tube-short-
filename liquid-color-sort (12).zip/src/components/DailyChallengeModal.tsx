import React from 'react';
import { motion } from 'motion/react';
import { X, Flame, Trophy, Coins, CheckCircle, Play, Tv, Sparkles, AlertCircle } from 'lucide-react';
import { sound } from '../utils/audio';

interface DailyChallengeModalProps {
  isCompletedToday: boolean;
  extraAttempts?: number;
  onPlayDailyChallenge: () => void;
  onWatchRewardedDailyAttempt: () => void;
  onClose: () => void;
}

export const DailyChallengeModal: React.FC<DailyChallengeModalProps> = ({
  isCompletedToday,
  extraAttempts = 0,
  onPlayDailyChallenge,
  onWatchRewardedDailyAttempt,
  onClose,
}) => {
  const todayStr = new Date().toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    weekday: 'long',
  });

  const canPlay = !isCompletedToday || extraAttempts > 0;

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 select-none">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="crystal-card w-full max-w-sm rounded-3xl border-rose-500/40 p-5 flex flex-col items-center text-center shadow-[0_0_60px_rgba(244,63,94,0.4)] relative overflow-hidden"
      >
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="crystal-button absolute top-4 right-4 p-1.5 rounded-full text-slate-300 hover:text-white border-white/10 active:scale-95 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/50 text-rose-400 text-xs font-black uppercase mb-2 shadow-[0_0_10px_rgba(244,63,94,0.3)]">
          <Flame className="w-4 h-4 animate-pulse" />
          <span>Daily Bonus Event</span>
        </div>

        {/* Title */}
        <h2 className="text-xl font-black text-white mb-0.5 tracking-wide">DAILY CHALLENGE</h2>
        <p className="text-xs text-rose-300 font-semibold mb-3">{todayStr}</p>

        {/* Puzzle Info Box */}
        <div className="w-full p-4 rounded-2xl bg-slate-950/60 border border-white/10 flex flex-col items-center gap-2.5 mb-4 shadow-inner">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]" />
            <div className="text-left">
              <h4 className="text-sm font-black text-white">
                {!isCompletedToday ? 'Daily Prism Puzzle' : 'Bonus Prism Puzzle'}
              </h4>
              <p className="text-[11px] text-slate-400 font-medium">
                {!isCompletedToday
                  ? 'Win 4,000 – 5,000 Coins on Completion!'
                  : 'Win 2,000 – 2,500 Coins on Completion!'}
              </p>
            </div>
          </div>

          <div className="w-full flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/40 text-xs font-bold text-slate-200">
            <span className="text-slate-300 font-medium">Completion Reward:</span>
            <div className="flex items-center gap-1.5 text-yellow-300 font-black text-sm">
              <Coins className="w-4.5 h-4.5 text-yellow-400" />
              <span>
                {!isCompletedToday ? '+4,000 to +5,000 Coins' : '+2,000 to +2,500 Coins'}
              </span>
            </div>
          </div>

          {extraAttempts > 0 && (
            <div className="w-full py-1 px-2.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 text-xs font-black flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{extraAttempts} Bonus Challenge{extraAttempts > 1 ? 's' : ''} Ready!</span>
            </div>
          )}

          <p className="text-[10px] text-slate-400 italic text-center leading-snug">
            * Reward is awarded ONLY upon solving the puzzle. Exiting or failing gives zero coins.
          </p>
        </div>

        {/* Action Buttons */}
        {canPlay ? (
          <button
            onClick={() => {
              sound.playClick();
              onPlayDailyChallenge();
            }}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-rose-500 via-amber-500 to-yellow-400 hover:from-rose-400 hover:to-yellow-300 text-slate-950 font-black text-sm tracking-wide uppercase transition-all shadow-[0_0_25px_rgba(244,63,94,0.6)] active:scale-95 flex items-center justify-center gap-2 border border-yellow-200 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-slate-950" />
            <span>{!isCompletedToday ? 'PLAY DAILY CHALLENGE (FREE)' : 'PLAY BONUS CHALLENGE'}</span>
          </button>
        ) : (
          <div className="w-full flex flex-col gap-2.5">
            <div className="w-full py-2.5 px-4 rounded-xl bg-slate-900/90 border border-white/10 text-slate-400 font-bold text-xs flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Free Daily Challenge Completed</span>
            </div>

            {/* Watch Ad for +1 Attempt */}
            <button
              onClick={() => {
                sound.playClick();
                onWatchRewardedDailyAttempt();
              }}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs sm:text-sm tracking-wide uppercase transition-all shadow-[0_0_25px_rgba(16,185,129,0.5)] active:scale-95 flex items-center justify-center gap-2 border border-teal-200 cursor-pointer"
            >
              <Tv className="w-4.5 h-4.5 text-slate-950 animate-pulse" />
              <span>Watch Ad to Unlock +1 Bonus Challenge</span>
            </button>
            <span className="text-[10px] text-slate-400">
              * Ad unlocks 1 new different puzzle. Complete it to win 2,000–2,500 coins.
            </span>
          </div>
        )}
      </motion.div>
    </div>
  );
};
