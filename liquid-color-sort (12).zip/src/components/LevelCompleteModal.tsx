import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { Star, Coins, ArrowRight, RefreshCw, Trophy, Sparkles, Tv, Zap } from 'lucide-react';
import { sound } from '../utils/audio';
import { ConfettiCelebration } from './ConfettiCelebration';

interface LevelCompleteModalProps {
  levelNumber: number;
  moves: number;
  stars: number;
  coinsEarned: number;
  isNewBest: boolean;
  isMilestone: boolean;
  milestoneRewardText?: string;
  isDoubleRewardClaimed?: boolean;
  isDailyChallenge?: boolean;
  onDoubleCoinsRewarded?: () => void;
  onNextLevel: () => void;
  onReplay: () => void;
}

export const LevelCompleteModal: React.FC<LevelCompleteModalProps> = ({
  levelNumber,
  moves,
  stars,
  coinsEarned,
  isNewBest,
  isMilestone,
  milestoneRewardText,
  isDoubleRewardClaimed = false,
  isDailyChallenge = false,
  onDoubleCoinsRewarded,
  onNextLevel,
  onReplay,
}) => {
  useEffect(() => {
    sound.playWin();

    // Trigger celebratory confetti explosion
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#38BDF8', '#FACC15', '#EC4899', '#10B981', '#8B5CF6'],
      });
    } catch {
      // ignore
    }
  }, []);

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 select-none animate-fade-in">
      {/* Fullscreen Falling Confetti & Ribbon Streamers */}
      <ConfettiCelebration />

      <motion.div
        initial={{ scale: 0.85, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 350, damping: 25 }}
        className={`crystal-card w-full max-w-sm rounded-3xl border-2 p-6 flex flex-col items-center text-center relative overflow-hidden ${
          isDailyChallenge
            ? 'border-rose-500/50 shadow-[0_0_60px_rgba(244,63,94,0.5)]'
            : 'border-cyan-500/40 shadow-[0_0_60px_rgba(6,182,212,0.4)]'
        }`}
      >
        {/* Background glow sheen */}
        <div
          className={`absolute -top-24 left-1/2 -translate-x-1/2 w-56 h-56 rounded-full blur-3xl pointer-events-none ${
            isDailyChallenge ? 'bg-rose-500/30' : 'bg-cyan-500/25'
          }`}
        />

        {/* Milestone Trophy Badge (if Level 10, 25, 50, etc.) */}
        {isMilestone && !isDailyChallenge && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 text-xs font-black uppercase tracking-wider mb-2 shadow-[0_0_15px_rgba(250,204,21,0.6)] animate-bounce border border-yellow-200">
            <Trophy className="w-3.5 h-3.5" />
            <span>Milestone Level!</span>
          </div>
        )}

        {isDailyChallenge && (
          <div className="flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-gradient-to-r from-rose-500 via-amber-500 to-yellow-400 text-slate-950 text-xs font-black uppercase tracking-wider mb-2 shadow-[0_0_18px_rgba(244,63,94,0.7)] animate-pulse border border-yellow-200">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Bonus Event Solved!</span>
          </div>
        )}

        {/* Header Title */}
        <h2 className="text-2xl font-black tracking-tight text-white mb-1 drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
          {isDailyChallenge
            ? '🔥 CHALLENGE WON! 🔥'
            : levelNumber === 200
            ? '👑 200 LEVELS MASTERED! 👑'
            : levelNumber > 200
            ? `♾️ UNLIMITED LEVEL ${levelNumber}!`
            : 'LEVEL COMPLETE!'}
        </h2>
        <p className="text-xs text-cyan-300 font-semibold mb-4">
          {isDailyChallenge
            ? 'Daily Challenge Mastered! Reward Claimed!'
            : levelNumber === 200
            ? 'Grand Finale Solved! Endless Unlimited Mode Unlocked!'
            : levelNumber > 200
            ? `Endless Master Level ${levelNumber} Solved Successfully`
            : `Level ${levelNumber} Sorted Successfully`}
        </p>

        {/* Star Rating Animation */}
        <div className="flex items-center justify-center gap-3 my-2">
          {[1, 2, 3].map((starIndex) => {
            const isEarned = starIndex <= stars;
            return (
              <motion.div
                key={starIndex}
                initial={{ scale: 0, rotate: -30 }}
                animate={{ scale: isEarned ? 1 : 0.7, rotate: 0 }}
                transition={{
                  delay: 0.15 + starIndex * 0.2,
                  type: 'spring',
                  stiffness: 350,
                  damping: 14,
                }}
              >
                <Star
                  className={`w-12 h-12 transition-all ${
                    isEarned
                      ? 'text-yellow-400 fill-yellow-400 drop-shadow-[0_0_16px_rgba(250,204,21,1)]'
                      : 'text-slate-700 fill-slate-800'
                  }`}
                />
              </motion.div>
            );
          })}
        </div>

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-3 my-4">
          {/* Moves Used */}
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-white/10 flex flex-col items-center shadow-inner">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Moves Used
            </span>
            <span className="text-xl font-black text-cyan-300 mt-0.5">
              {moves}
            </span>
            {isNewBest && !isDailyChallenge && (
              <span className="text-[9px] font-black text-emerald-400 uppercase tracking-tight">
                ★ New Best!
              </span>
            )}
          </div>

          {/* Coins Earned */}
          <div className="p-3 rounded-2xl bg-slate-950/60 border border-white/10 flex flex-col items-center shadow-inner">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Coins Earned
            </span>
            <div className="flex items-center gap-1 mt-0.5 text-xl font-black text-yellow-400">
              <Coins className="w-5 h-5 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]" />
              <span>+{coinsEarned.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Milestone Extra Reward Announcement */}
        {milestoneRewardText && (
          <div className="w-full mb-3 p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-xs font-bold flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(245,158,11,0.2)]">
            <Sparkles className="w-4 h-4 text-yellow-400 shrink-0" />
            <span>{milestoneRewardText}</span>
          </div>
        )}

        {/* Rewarded Interstitial Option: Double Coins */}
        {onDoubleCoinsRewarded && !isDoubleRewardClaimed && (
          <button
            onClick={() => {
              sound.playClick();
              onDoubleCoinsRewarded();
            }}
            className="w-full mb-3 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/20 border border-yellow-400/50 hover:border-yellow-400 text-yellow-300 font-black text-xs flex items-center justify-center gap-2 active:scale-95 transition-all shadow-[0_0_15px_rgba(250,204,21,0.2)] animate-pulse cursor-pointer"
          >
            <Tv className="w-4 h-4 text-yellow-400" />
            <span>Watch Ad to Double Coins (+{coinsEarned.toLocaleString()})</span>
          </button>
        )}

        {isDoubleRewardClaimed && (
          <div className="w-full mb-3 py-1.5 px-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>2X Bonus Claimed! (+{(coinsEarned * 2).toLocaleString()} Coins Total)</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="w-full flex items-center gap-3 mt-2">
          <button
            onClick={() => {
              sound.playClick();
              onReplay();
            }}
            className="crystal-button flex-1 min-h-[50px] py-3 px-4 rounded-2xl border-white/15 text-slate-200 font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md touch-manipulation cursor-pointer"
          >
            <RefreshCw className="w-4.5 h-4.5 text-rose-400" />
            <span>Replay</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onNextLevel();
            }}
            className={`flex-2 min-h-[50px] py-3.5 px-4 rounded-2xl active:scale-95 text-slate-950 font-black text-sm flex items-center justify-center gap-2 transition-all shadow-[0_0_25px_rgba(6,182,212,0.6)] touch-manipulation cursor-pointer ${
              isDailyChallenge
                ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 hover:from-amber-300 hover:to-yellow-200 border border-yellow-200 shadow-[0_0_25px_rgba(251,191,36,0.6)]'
                : 'bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 border border-cyan-200'
            }`}
          >
            <span>{isDailyChallenge ? 'Return to Menu' : levelNumber === 200 ? 'Play Unlimited Mode' : `Next Level (${levelNumber + 1})`}</span>
            <ArrowRight className="w-4.5 h-4.5 text-slate-950 stroke-[3]" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};
