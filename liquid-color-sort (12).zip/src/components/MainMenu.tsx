import React from 'react';
import { motion } from 'motion/react';
import { Play, Grid, Sparkles, ShoppingBag, Calendar, Settings, Star, Coins, Trophy, Flame, Infinity as InfinityIcon } from 'lucide-react';
import { sound } from '../utils/audio';
import { LocationTheme } from '../utils/shopData';
import { AdMobBanner } from './AdMobBanner';

interface MainMenuProps {
  unlockedLevel: number;
  coins: number;
  starsCount: number;
  freeSpins: number;
  isDailySpinAvailable?: boolean;
  hasDailyReward: boolean;
  activeLocation: LocationTheme;
  onPlayCurrentLevel: () => void;
  onOpenLevelSelect: () => void;
  onOpenSpin: () => void;
  onOpenShop: () => void;
  onOpenDailyReward: () => void;
  onOpenDailyChallenge: () => void;
  onOpenSettings: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  unlockedLevel,
  coins,
  starsCount,
  freeSpins,
  isDailySpinAvailable = false,
  hasDailyReward,
  activeLocation,
  onPlayCurrentLevel,
  onOpenLevelSelect,
  onOpenSpin,
  onOpenShop,
  onOpenDailyReward,
  onOpenDailyChallenge,
  onOpenSettings,
}) => {
  return (
    <div className="relative w-full h-full flex flex-col justify-between p-3.5 sm:p-5 select-none overflow-hidden safe-top safe-bottom safe-x touch-manipulation">
      {/* Top Currency & Status Header */}
      <div className="flex items-center justify-between z-20">
        {/* Stars Pill */}
        <div className="crystal-card min-h-[44px] flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-yellow-400 shadow-md">
          <Star className="w-4.5 h-4.5 fill-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]" />
          <span className="text-xs font-black tracking-wide">{starsCount} / 600</span>
        </div>

        {/* Version Badge */}
        <div className="px-2.5 py-1 rounded-full bg-cyan-950/70 border border-cyan-500/40 text-[10px] font-black uppercase tracking-wider text-cyan-300 shadow-sm flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-cyan-400" />
          <span>v2.4 Premium</span>
        </div>

        {/* Coins Pill & Settings Button */}
        <div className="flex items-center gap-2">
          <div
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            className="crystal-card min-h-[44px] flex items-center gap-1.5 px-3 py-1.5 rounded-2xl border-amber-500/40 text-yellow-300 shadow-md cursor-pointer active:scale-95 transition-all touch-manipulation"
          >
            <Coins className="w-4.5 h-4.5 text-yellow-400 drop-shadow-[0_0_4px_rgba(250,204,21,0.7)]" />
            <span className="text-xs font-black tracking-wide">{coins}</span>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onOpenSettings();
            }}
            className="crystal-button min-h-[44px] min-w-[44px] flex items-center justify-center p-2 rounded-2xl text-slate-300 hover:text-white active:scale-95 transition-all shadow-md touch-manipulation"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Hero Title & Animated 3D Crystal Bottle Mascot */}
      <div className="flex flex-col items-center justify-center my-auto z-20 text-center">
        {/* Animated Brand Logo with 3D Crystal Tubes */}
        <motion.div
          animate={{ y: [-5, 5, -5] }}
          transition={{ repeat: Infinity, duration: 3.5, ease: 'easeInOut' }}
          className="relative mb-3 flex items-center justify-center"
        >
          {/* Glowing Radial Aura */}
          <div className="absolute w-36 h-36 bg-gradient-to-tr from-cyan-500 via-sky-400 to-fuchsia-500 rounded-full blur-3xl opacity-35 animate-pulse" />

          {/* Stylized Crystal Test Tube Trio Mascot */}
          <div className="crystal-card flex items-end gap-2.5 p-3.5 rounded-3xl border-2 border-white/20 shadow-[0_12px_40px_rgba(0,0,0,0.6)]">
            {/* Tube 1: Ruby Red / Pink */}
            <div className="relative w-6 h-18 rounded-b-xl rounded-t-sm border border-white/60 bg-slate-950/60 overflow-hidden flex flex-col justify-end p-0.5 shadow-inner">
              <div className="absolute left-0.5 top-1 bottom-1 w-0.5 rounded-full bg-white/70 pointer-events-none z-10" />
              <div className="h-12 w-full bg-gradient-to-t from-pink-600 via-pink-500 to-rose-400 rounded-b-lg relative">
                <div className="w-1 h-1 bg-white rounded-full absolute top-2 left-1.5 opacity-80" />
              </div>
            </div>

            {/* Center Tube: Cyan Crystal (Main Hero) */}
            <div className="relative w-8 h-24 rounded-b-2xl rounded-t-sm border-2 border-white/80 bg-slate-950/70 overflow-hidden flex flex-col justify-end p-0.5 shadow-[0_0_20px_rgba(6,182,212,0.5)]">
              <div className="absolute left-0.5 top-1 bottom-1 w-1 rounded-full bg-white/90 pointer-events-none z-10 shadow-[0_0_4px_#fff]" />
              <div className="h-18 w-full bg-gradient-to-t from-cyan-600 via-cyan-400 to-sky-200 rounded-b-xl relative">
                <div className="w-1.5 h-1.5 bg-white rounded-full absolute top-2 left-2 animate-ping" />
                <div className="w-1 h-1 bg-white rounded-full absolute bottom-3 right-2 opacity-90" />
              </div>
            </div>

            {/* Tube 3: Amethyst Purple */}
            <div className="relative w-6 h-18 rounded-b-xl rounded-t-sm border border-white/60 bg-slate-950/60 overflow-hidden flex flex-col justify-end p-0.5 shadow-inner">
              <div className="absolute left-0.5 top-1 bottom-1 w-0.5 rounded-full bg-white/70 pointer-events-none z-10" />
              <div className="h-11 w-full bg-gradient-to-t from-purple-600 via-purple-500 to-violet-400 rounded-b-lg relative">
                <div className="w-1 h-1 bg-white rounded-full absolute top-2 left-1.5 opacity-80" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-white to-fuchsia-200 drop-shadow-[0_4px_16px_rgba(6,182,212,0.5)]">
          LIQUID COLOR SORT
        </h1>
        <p className="text-xs sm:text-sm font-bold text-slate-300 tracking-wide mt-1">
          {unlockedLevel > 200
            ? `♾️ Endless Master Mode Active • Level ${unlockedLevel}`
            : 'Endless Liquid Color Sorting Puzzles (1 to 10,000+)'}
        </p>

        {/* Level Progression Banner */}
        <div className={`mt-3 px-4 py-1.5 rounded-full crystal-card flex items-center gap-2 shadow-inner ${
          unlockedLevel > 200 ? 'border-fuchsia-500/50 bg-fuchsia-950/40 shadow-[0_0_15px_rgba(217,70,239,0.3)]' : ''
        }`}>
          {unlockedLevel > 200 ? (
            <InfinityIcon className="w-4 h-4 text-fuchsia-400 animate-pulse" />
          ) : (
            <Trophy className="w-4 h-4 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.8)]" />
          )}
          <span className="text-xs font-black text-slate-200">
            {unlockedLevel > 200 ? (
              <>Unlimited Mode: <strong className="text-fuchsia-300">Level {unlockedLevel}</strong></>
            ) : (
              <>Current Progress: <strong className="text-cyan-300">Level {unlockedLevel}</strong> (Endless)</>
            )}
          </span>
        </div>
      </div>

      {/* Action Buttons Grid */}
      <div className="w-full max-w-sm mx-auto flex flex-col gap-2.5 z-20">
        {/* BIG PLAY BUTTON */}
        <button
          onClick={() => {
            sound.playClick();
            onPlayCurrentLevel();
          }}
          className={`w-full min-h-[56px] py-4 px-6 rounded-2xl text-slate-950 font-black text-base tracking-wider uppercase shadow-[0_0_30px_rgba(6,182,212,0.6)] active:scale-95 transition-all flex items-center justify-center gap-3 group border touch-manipulation cursor-pointer ${
            unlockedLevel > 200
              ? 'bg-gradient-to-r from-fuchsia-400 via-pink-400 to-amber-300 hover:from-fuchsia-300 hover:to-amber-200 border-fuchsia-200 shadow-[0_0_35px_rgba(217,70,239,0.7)]'
              : 'bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 border-cyan-200'
          }`}
        >
          <Play className="w-6 h-6 fill-slate-950 group-hover:scale-110 transition-transform" />
          <span>{unlockedLevel > 200 ? `PLAY LEVEL ${unlockedLevel} (UNLIMITED)` : `PLAY LEVEL ${unlockedLevel}`}</span>
        </button>

        {/* Secondary Row: Levels, Spin, Shop */}
        <div className="grid grid-cols-3 gap-2.5">
          {/* LEVEL SELECT */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenLevelSelect();
            }}
            className="crystal-button min-h-[54px] py-2.5 px-2 rounded-2xl text-slate-200 font-black text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all shadow-md touch-manipulation cursor-pointer"
          >
            <Grid className="w-5 h-5 text-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.6)]" />
            <span>Levels</span>
          </button>

          {/* SPIN PRIZE WHEEL */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenSpin();
            }}
            className="crystal-button relative min-h-[54px] py-2.5 px-2 rounded-2xl border-amber-500/40 text-slate-200 font-black text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all shadow-md touch-manipulation cursor-pointer"
          >
            <Sparkles className="w-5 h-5 text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.7)] animate-pulse" />
            <span>Spin</span>
            {(isDailySpinAvailable || freeSpins > 0) && (
              <span className="absolute -top-1.5 -right-1 px-1.5 py-0.5 rounded-full text-[9px] font-black bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow-[0_0_10px_rgba(250,204,21,0.9)] border border-white animate-bounce">
                {isDailySpinAvailable ? 'Free' : freeSpins}
              </span>
            )}
          </button>

          {/* SHOP */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            className="crystal-button min-h-[54px] py-2.5 px-2 rounded-2xl text-slate-200 font-black text-xs flex flex-col items-center justify-center gap-1 active:scale-95 transition-all shadow-md touch-manipulation cursor-pointer"
          >
            <ShoppingBag className="w-5 h-5 text-pink-400 drop-shadow-[0_0_6px_rgba(244,114,182,0.6)]" />
            <span>Shop</span>
          </button>
        </div>

        {/* Third Row: Daily Reward & Daily Challenge */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* DAILY REWARD */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenDailyReward();
            }}
            className="crystal-button relative min-h-[48px] py-2.5 px-3 rounded-2xl bg-gradient-to-r from-purple-950/80 to-slate-900/90 border-purple-500/50 text-purple-200 font-black text-xs flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md touch-manipulation cursor-pointer"
          >
            <Calendar className="w-4.5 h-4.5 text-purple-400 shrink-0" />
            <span>Daily Reward</span>
            {hasDailyReward && (
              <span className="w-2 h-2 rounded-full bg-pink-400 animate-ping absolute top-2 right-2" />
            )}
          </button>

          {/* DAILY CHALLENGE */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenDailyChallenge();
            }}
            className="crystal-button relative min-h-[48px] py-2.5 px-3 rounded-2xl bg-gradient-to-r from-rose-950/80 to-slate-900/90 border-rose-500/50 text-rose-200 font-black text-xs flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md touch-manipulation cursor-pointer"
          >
            <Flame className="w-4.5 h-4.5 text-rose-400 shrink-0" />
            <span>Challenge</span>
          </button>
        </div>

        {/* AdMob Adaptive Banner */}
        <AdMobBanner className="pt-1" />
      </div>
    </div>
  );
};
