import React, { useEffect, useRef } from 'react';

interface AnimatedGameBackgroundProps {
  themeId?: string;
}

export const AnimatedGameBackground: React.FC<AnimatedGameBackgroundProps> = ({
  themeId = 'snow_aurora',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initThemeParticles();
    };

    window.addEventListener('resize', handleResize);

    // Particle storage
    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      color: string;
      alpha: number;
      maxAlpha: number;
      angle: number;
      spin: number;
      life: number;
      maxLife: number;
      customData?: any;
    }

    const particles: Particle[] = [];

    const initThemeParticles = () => {
      particles.length = 0;
      const count = Math.min(100, Math.floor(width * 0.08) + 35);

      for (let i = 0; i < count; i++) {
        particles.push(createParticle(true));
      }
    };

    const createParticle = (isInitial = false): Particle => {
      const p: Particle = {
        x: Math.random() * width,
        y: isInitial ? Math.random() * height : -20,
        vx: (Math.random() - 0.5) * 0.8,
        vy: 0.8 + Math.random() * 1.5,
        size: 2 + Math.random() * 3,
        color: '#ffffff',
        alpha: 0.3 + Math.random() * 0.5,
        maxAlpha: 0.8,
        angle: Math.random() * Math.PI * 2,
        spin: (Math.random() - 0.5) * 0.04,
        life: Math.random() * 100,
        maxLife: 100 + Math.random() * 150,
      };

      // Custom configuration based on themeId
      switch (themeId) {
        case 'sakura_bloom':
          p.color = Math.random() > 0.3 ? '#f472b6' : '#fbcfe8';
          p.size = 3.5 + Math.random() * 4.5;
          p.vx = 0.5 + Math.random() * 1.2;
          p.vy = 0.8 + Math.random() * 1.2;
          p.customData = { wobble: Math.random() * 10, wobbleSpeed: 0.02 + Math.random() * 0.03 };
          break;

        case 'cyber_matrix':
          p.color = Math.random() > 0.4 ? '#22c55e' : '#06b6d4';
          p.size = 10 + Math.random() * 6;
          p.vx = 0;
          p.vy = 2.5 + Math.random() * 4;
          p.customData = {
            char: String.fromCharCode(0x30a0 + Math.floor(Math.random() * 96)),
            charChange: 0,
          };
          break;

        case 'magic_fireflies':
          p.color = Math.random() > 0.5 ? '#fef08a' : '#86efac';
          p.size = 2.5 + Math.random() * 3.5;
          p.vx = (Math.random() - 0.5) * 0.7;
          p.vy = (Math.random() - 0.5) * 0.6;
          p.y = Math.random() * height;
          p.customData = { pulseSpeed: 0.03 + Math.random() * 0.04, phase: Math.random() * Math.PI * 2 };
          break;

        case 'cosmic_galaxy':
          p.color = Math.random() > 0.6 ? '#c084fc' : Math.random() > 0.3 ? '#67e8f9' : '#ffffff';
          p.size = 1 + Math.random() * 2.5;
          p.vx = (Math.random() - 0.5) * 0.3;
          p.vy = (Math.random() - 0.5) * 0.3;
          p.y = Math.random() * height;
          break;

        case 'ocean_reef':
          p.color = '#38bdf8';
          p.size = 2 + Math.random() * 4.5;
          p.vx = (Math.random() - 0.5) * 0.4;
          p.vy = -(0.8 + Math.random() * 1.4); // Rising bubbles
          p.y = isInitial ? Math.random() * height : height + 15;
          break;

        case 'volcano_inferno':
        case 'dragon_lair':
          p.color = Math.random() > 0.5 ? '#f97316' : Math.random() > 0.2 ? '#ef4444' : '#fbbf24';
          p.size = 1.5 + Math.random() * 3;
          p.vx = (Math.random() - 0.5) * 1.2;
          p.vy = -(1.2 + Math.random() * 2.2); // Rising sparks
          p.y = isInitial ? Math.random() * height : height + 10;
          break;

        case 'thunder_storm':
          p.color = '#93c5fd';
          p.size = 1.5;
          p.vx = 2.5 + Math.random() * 1.5;
          p.vy = 12 + Math.random() * 8; // Heavy fast rain
          break;

        case 'autumn_leaves':
          p.color = Math.random() > 0.6 ? '#ea580c' : Math.random() > 0.3 ? '#f59e0b' : '#b91c1c';
          p.size = 4 + Math.random() * 5;
          p.vx = 0.8 + Math.random() * 1.5;
          p.vy = 1 + Math.random() * 1.2;
          break;

        case 'golden_palace':
          p.color = Math.random() > 0.4 ? '#fde047' : '#fbbf24';
          p.size = 2 + Math.random() * 3;
          p.vx = (Math.random() - 0.5) * 0.6;
          p.vy = 0.6 + Math.random() * 1.2;
          break;

        case 'hyper_drive':
          p.x = width / 2;
          p.y = height / 2;
          const rad = Math.random() * Math.PI * 2;
          const spd = 2 + Math.random() * 6;
          p.vx = Math.cos(rad) * spd;
          p.vy = Math.sin(rad) * spd;
          p.size = 1.2 + Math.random() * 2;
          p.color = Math.random() > 0.3 ? '#38bdf8' : '#e0e7ff';
          break;

        default:
          // snow_aurora & general default
          p.color = '#ffffff';
          p.size = 1.5 + Math.random() * 3;
          p.vy = 0.8 + Math.random() * 1.2;
          p.vx = (Math.random() - 0.5) * 0.4;
          break;
      }

      return p;
    };

    initThemeParticles();

    let time = 0;
    let meteor = { x: -100, y: -100, vx: 0, vy: 0, life: 0, active: false };
    let lightningTime = 0;

    const render = () => {
      time += 0.018;
      ctx.clearRect(0, 0, width, height);

      // --- LAYER 1: Dynamic Sky/Ambient Atmosphere Renderers ---
      switch (themeId) {
        case 'snow_aurora':
        case 'emerald_aurora': {
          // Aurora Waves
          const auroraColor1 = themeId === 'emerald_aurora' ? 'rgba(16, 185, 129, ' : 'rgba(6, 182, 212, ';
          const auroraColor2 = themeId === 'emerald_aurora' ? 'rgba(20, 184, 166, ' : 'rgba(59, 130, 246, ';
          const auroraWave = Math.sin(time * 0.8) * 0.1 + 0.22;
          
          const grad = ctx.createLinearGradient(0, 0, width, height * 0.6);
          grad.addColorStop(0, `${auroraColor1}${auroraWave})`);
          grad.addColorStop(0.5, `${auroraColor2}${auroraWave * 0.8})`);
          grad.addColorStop(1, 'transparent');
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, width, height * 0.7);

          // Flowing ribbon
          ctx.save();
          ctx.beginPath();
          ctx.moveTo(0, height * 0.15);
          for (let x = 0; x <= width; x += 30) {
            const yOff = Math.sin(x * 0.005 + time * 0.9) * 25 + Math.cos(x * 0.009 - time * 0.7) * 15;
            ctx.lineTo(x, height * 0.16 + yOff);
          }
          ctx.lineTo(width, 0);
          ctx.lineTo(0, 0);
          ctx.closePath();
          ctx.fillStyle = themeId === 'emerald_aurora' ? 'rgba(52, 211, 153, 0.18)' : 'rgba(56, 189, 248, 0.2)';
          ctx.fill();
          ctx.restore();
          break;
        }

        case 'neon_synthwave': {
          // Retro Glowing Sun on Horizon
          const sunY = height * 0.62;
          const sunRadius = Math.min(width * 0.22, 90);
          const sunGrad = ctx.createLinearGradient(0, sunY - sunRadius, 0, sunY + sunRadius);
          sunGrad.addColorStop(0, '#fde047');
          sunGrad.addColorStop(0.5, '#f43f5e');
          sunGrad.addColorStop(1, '#a855f7');
          
          ctx.save();
          ctx.beginPath();
          ctx.arc(width / 2, sunY, sunRadius, 0, Math.PI * 2);
          ctx.fillStyle = sunGrad;
          ctx.shadowColor = '#f43f5e';
          ctx.shadowBlur = 25;
          ctx.fill();
          ctx.restore();

          // Slicing horizontal lines on sun
          for (let s = 1; s <= 6; s++) {
            const lineY = sunY + (s / 7) * sunRadius;
            ctx.fillStyle = '#09090b';
            ctx.fillRect(width / 2 - sunRadius, lineY, sunRadius * 2, 2 + s * 0.8);
          }

          // 3D Perspective Grid
          ctx.save();
          ctx.strokeStyle = 'rgba(217, 70, 239, 0.35)';
          ctx.lineWidth = 1.2;
          const horizonY = height * 0.65;
          // Grid vertical perspective lines
          for (let x = -width; x <= width * 2; x += 40) {
            ctx.beginPath();
            ctx.moveTo(width / 2, horizonY);
            ctx.lineTo(x, height);
            ctx.stroke();
          }
          // Grid horizontal lines moving
          const gridSpeed = (time * 40) % 30;
          for (let y = horizonY; y <= height; y += 15) {
            const curY = y + gridSpeed * ((y - horizonY) / (height - horizonY));
            if (curY <= height) {
              ctx.beginPath();
              ctx.moveTo(0, curY);
              ctx.lineTo(width, curY);
              ctx.stroke();
            }
          }
          ctx.restore();
          break;
        }

        case 'thunder_storm': {
          // Occasional Lightning Flash
          if (Math.random() < 0.007 && lightningTime <= 0) {
            lightningTime = 6;
          }
          if (lightningTime > 0) {
            lightningTime--;
            ctx.fillStyle = `rgba(186, 230, 253, ${0.15 + (lightningTime / 6) * 0.35})`;
            ctx.fillRect(0, 0, width, height);

            // Draw Lightning bolt
            if (lightningTime >= 4) {
              ctx.save();
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = 2.5;
              ctx.shadowColor = '#38bdf8';
              ctx.shadowBlur = 12;
              ctx.beginPath();
              let lx = width * (0.2 + Math.random() * 0.6);
              let ly = 0;
              ctx.moveTo(lx, ly);
              while (ly < height * 0.65) {
                lx += (Math.random() - 0.5) * 45;
                ly += 25 + Math.random() * 30;
                ctx.lineTo(lx, ly);
              }
              ctx.stroke();
              ctx.restore();
            }
          }
          break;
        }

        case 'ocean_reef': {
          // Sun rays piercing water
          ctx.save();
          for (let r = 0; r < 5; r++) {
            const rayX = width * (0.15 + r * 0.2) + Math.sin(time * 0.6 + r) * 20;
            const rayGrad = ctx.createLinearGradient(rayX, 0, rayX + 60, height * 0.85);
            rayGrad.addColorStop(0, 'rgba(56, 189, 248, 0.18)');
            rayGrad.addColorStop(0.6, 'rgba(20, 184, 166, 0.08)');
            rayGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = rayGrad;
            ctx.beginPath();
            ctx.moveTo(rayX - 10, 0);
            ctx.lineTo(rayX + 30, 0);
            ctx.lineTo(rayX + 90, height * 0.85);
            ctx.lineTo(rayX + 10, height * 0.85);
            ctx.closePath();
            ctx.fill();
          }
          ctx.restore();
          break;
        }

        case 'cosmic_galaxy':
        case 'black_hole': {
          // Nebula vortex
          ctx.save();
          const cx = width / 2;
          const cy = height * 0.45;
          const nebGrad = ctx.createRadialGradient(cx, cy, 10, cx, cy, Math.min(width * 0.6, 280));
          nebGrad.addColorStop(0, 'rgba(192, 132, 252, 0.25)');
          nebGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.12)');
          nebGrad.addColorStop(1, 'transparent');
          ctx.fillStyle = nebGrad;
          ctx.beginPath();
          ctx.arc(cx, cy, Math.min(width * 0.6, 280), 0, Math.PI * 2);
          ctx.fill();

          if (themeId === 'black_hole') {
            // Accretion Disk & Event Horizon
            ctx.beginPath();
            ctx.arc(cx, cy, 32, 0, Math.PI * 2);
            ctx.fillStyle = '#000000';
            ctx.shadowColor = '#c084fc';
            ctx.shadowBlur = 18;
            ctx.fill();
            ctx.shadowBlur = 0;

            // Orbiting relativistic photon ring
            ctx.beginPath();
            ctx.ellipse(cx, cy, 68, 22, time * 0.4, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(234, 88, 12, 0.65)';
            ctx.lineWidth = 3.5;
            ctx.stroke();
          }
          ctx.restore();

          // Shooting meteor
          if (!meteor.active && Math.random() < 0.015) {
            meteor = {
              x: Math.random() * width,
              y: Math.random() * (height * 0.4),
              vx: -(6 + Math.random() * 8),
              vy: 5 + Math.random() * 6,
              life: 25,
              active: true,
            };
          }
          if (meteor.active) {
            meteor.x += meteor.vx;
            meteor.y += meteor.vy;
            meteor.life--;
            if (meteor.life <= 0) meteor.active = false;

            ctx.save();
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(meteor.x, meteor.y);
            ctx.lineTo(meteor.x - meteor.vx * 3, meteor.y - meteor.vy * 3);
            ctx.stroke();
            ctx.restore();
          }
          break;
        }

        case 'disco_equalizer': {
          // Music Equalizer Bars on the bottom/back
          ctx.save();
          const barCount = 18;
          const barWidth = width / barCount;
          for (let b = 0; b < barCount; b++) {
            const barHeight = Math.abs(Math.sin(time * 3 + b * 0.5)) * (height * 0.28) + 20;
            const barGrad = ctx.createLinearGradient(0, height - barHeight, 0, height);
            barGrad.addColorStop(0, '#06b6d4');
            barGrad.addColorStop(0.5, '#ec4899');
            barGrad.addColorStop(1, 'rgba(15, 23, 42, 0.2)');
            ctx.fillStyle = barGrad;
            ctx.fillRect(b * barWidth + 4, height - barHeight, barWidth - 8, barHeight);
          }

          // Rotating Laser Beams
          for (let l = 0; l < 3; l++) {
            const laserAngle = Math.sin(time * 0.8 + l * 1.5) * 0.6;
            ctx.strokeStyle = l === 0 ? 'rgba(6, 182, 212, 0.35)' : l === 1 ? 'rgba(236, 72, 153, 0.35)' : 'rgba(168, 85, 247, 0.35)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(width / 2, 0);
            ctx.lineTo(width / 2 + Math.tan(laserAngle) * height, height);
            ctx.stroke();
          }
          ctx.restore();
          break;
        }

        case 'steampunk_clock': {
          // Clockwork gears rotating
          ctx.save();
          const drawGear = (gx: number, gy: number, radius: number, speed: number, teeth = 12) => {
            ctx.save();
            ctx.translate(gx, gy);
            ctx.rotate(time * speed);
            ctx.strokeStyle = 'rgba(217, 119, 6, 0.35)';
            ctx.lineWidth = 2.5;

            ctx.beginPath();
            ctx.arc(0, 0, radius, 0, Math.PI * 2);
            ctx.stroke();

            // Inner hub
            ctx.beginPath();
            ctx.arc(0, 0, radius * 0.35, 0, Math.PI * 2);
            ctx.stroke();

            // Teeth
            for (let t = 0; t < teeth; t++) {
              ctx.rotate((Math.PI * 2) / teeth);
              ctx.strokeRect(-radius * 0.12, radius * 0.9, radius * 0.24, radius * 0.2);
            }
            ctx.restore();
          };

          drawGear(width * 0.2, height * 0.25, 55, 0.3, 14);
          drawGear(width * 0.2 + 85, height * 0.25 + 40, 38, -0.45, 10);
          drawGear(width * 0.82, height * 0.35, 70, -0.25, 16);
          ctx.restore();
          break;
        }

        case 'quantum_realm': {
          // Atomic Orbital Rings
          ctx.save();
          const qx = width / 2;
          const qy = height * 0.45;
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.35)';
          ctx.lineWidth = 1.5;

          for (let ring = 0; ring < 3; ring++) {
            ctx.beginPath();
            ctx.ellipse(qx, qy, 90, 35, time * 0.5 + ring * (Math.PI / 3), 0, Math.PI * 2);
            ctx.stroke();

            // Orbiting electron node
            const eAngle = time * (1.8 + ring * 0.4);
            const ex = qx + Math.cos(eAngle) * 90 * Math.cos(time * 0.5 + ring * (Math.PI / 3)) - Math.sin(eAngle) * 35 * Math.sin(time * 0.5 + ring * (Math.PI / 3));
            const ey = qy + Math.cos(eAngle) * 90 * Math.sin(time * 0.5 + ring * (Math.PI / 3)) + Math.sin(eAngle) * 35 * Math.cos(time * 0.5 + ring * (Math.PI / 3));

            ctx.beginPath();
            ctx.arc(ex, ey, 3.5, 0, Math.PI * 2);
            ctx.fillStyle = '#67e8f9';
            ctx.shadowColor = '#06b6d4';
            ctx.shadowBlur = 8;
            ctx.fill();
            ctx.shadowBlur = 0;
          }
          ctx.restore();
          break;
        }
      }

      // --- LAYER 2: Physics Particles Simulation ---
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Specific particle behaviors
        if (themeId === 'sakura_bloom') {
          p.x += p.vx + Math.sin(time * 2 + p.customData.wobble) * 0.8;
          p.y += p.vy;
          p.angle += p.spin;

          if (p.y > height + 20) {
            particles[i] = createParticle(false);
            continue;
          }

          // Draw Sakura Petal Shape
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.angle);
          ctx.fillStyle = p.color;
          ctx.globalAlpha = p.alpha;
          ctx.beginPath();
          ctx.ellipse(0, 0, p.size, p.size * 0.55, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (themeId === 'cyber_matrix') {
          p.y += p.vy;
          p.customData.charChange++;
          if (p.customData.charChange > 12) {
            p.customData.char = String.fromCharCode(0x30a0 + Math.floor(Math.random() * 96));
            p.customData.charChange = 0;
          }

          if (p.y > height + 20) {
            particles[i] = createParticle(false);
            continue;
          }

          ctx.save();
          ctx.font = `${p.size}px monospace`;
          ctx.fillStyle = p.color;
          ctx.globalAlpha = p.alpha;
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 6;
          ctx.fillText(p.customData.char, p.x, p.y);
          ctx.restore();
        } else if (themeId === 'magic_fireflies') {
          p.customData.phase += p.customData.pulseSpeed;
          const pulse = (Math.sin(p.customData.phase) + 1) / 2;
          p.x += p.vx + Math.sin(p.customData.phase * 0.5) * 0.5;
          p.y += p.vy + Math.cos(p.customData.phase * 0.7) * 0.5;

          // Wrap boundaries smoothly
          if (p.x < 0) p.x = width;
          if (p.x > width) p.x = 0;
          if (p.y < 0) p.y = height;
          if (p.y > height) p.y = 0;

          ctx.save();
          const fireflyGrad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * (2 + pulse * 2));
          fireflyGrad.addColorStop(0, p.color);
          fireflyGrad.addColorStop(0.3, `rgba(254, 240, 138, ${0.4 * pulse})`);
          fireflyGrad.addColorStop(1, 'transparent');
          ctx.fillStyle = fireflyGrad;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (2 + pulse * 2), 0, Math.PI * 2);
          ctx.fill();

          // Center bright spark
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.6, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (themeId === 'ocean_reef') {
          // Rising bubbles with wobble
          p.y += p.vy;
          p.x += p.vx + Math.sin(time * 3 + i) * 0.6;

          if (p.y < -20) {
            particles[i] = createParticle(false);
            continue;
          }

          ctx.save();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.stroke();

          // Bubble specular highlight
          ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
          ctx.beginPath();
          ctx.arc(p.x - p.size * 0.35, p.y - p.size * 0.35, p.size * 0.3, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (themeId === 'volcano_inferno' || themeId === 'dragon_lair') {
          // Rising ember sparks
          p.y += p.vy;
          p.x += p.vx + (Math.random() - 0.5) * 0.5;
          p.alpha -= 0.005;

          if (p.y < -20 || p.alpha <= 0) {
            particles[i] = createParticle(false);
            continue;
          }

          ctx.save();
          ctx.fillStyle = p.color;
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (themeId === 'thunder_storm') {
          // Fast rain streak
          p.x += p.vx;
          p.y += p.vy;

          if (p.y > height + 20) {
            particles[i] = createParticle(false);
            continue;
          }

          ctx.save();
          ctx.strokeStyle = 'rgba(186, 230, 253, 0.65)';
          ctx.lineWidth = p.size;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 1.5, p.y - p.vy * 1.5);
          ctx.stroke();
          ctx.restore();
        } else if (themeId === 'hyper_drive') {
          // Streaking warp lines outward
          p.x += p.vx;
          p.y += p.vy;
          p.vx *= 1.05;
          p.vy *= 1.05;

          if (p.x < 0 || p.x > width || p.y < 0 || p.y > height) {
            particles[i] = createParticle(false);
            continue;
          }

          ctx.save();
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.size;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.4, p.y - p.vy * 0.4);
          ctx.stroke();
          ctx.restore();
        } else {
          // Standard / Snow / Stardust / Golden Dust / Autumn Fall
          p.y += p.vy;
          p.x += p.vx + Math.sin(time * 2 + i) * 0.5;

          if (p.y > height + 20) {
            particles[i] = createParticle(false);
            continue;
          }

          ctx.save();
          ctx.fillStyle = p.color;
          ctx.globalAlpha = p.alpha;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [themeId]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
      style={{ filter: 'drop-shadow(0 0 10px rgba(0,0,0,0.25))' }}
    />
  );
};
