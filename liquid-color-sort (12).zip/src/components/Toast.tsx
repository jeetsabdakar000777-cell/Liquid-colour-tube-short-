import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Info, AlertCircle, CheckCircle, Sparkles } from 'lucide-react';

export interface ToastMessage {
  id: string;
  text: string;
  type?: 'info' | 'error' | 'success' | 'magic';
}

interface ToastProps {
  toast: ToastMessage | null;
}

export const Toast: React.FC<ToastProps> = ({ toast }) => {
  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          className="fixed top-16 left-1/2 -translate-x-1/2 z-50 pointer-events-none max-w-[90vw]"
        >
          <div
            className={`flex items-center gap-2.5 px-4 py-2.5 rounded-2xl shadow-[0_10px_25px_rgba(0,0,0,0.5)] border backdrop-blur-md text-xs sm:text-sm font-bold ${
              toast.type === 'error'
                ? 'bg-rose-950/90 border-rose-600/70 text-rose-200'
                : toast.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/70 text-emerald-200'
                : toast.type === 'magic'
                ? 'bg-purple-950/90 border-purple-500/70 text-purple-200'
                : 'bg-slate-900/90 border-cyan-500/70 text-cyan-200'
            }`}
          >
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
            {toast.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
            {toast.type === 'magic' && <Sparkles className="w-4 h-4 text-purple-300 shrink-0" />}
            {(!toast.type || toast.type === 'info') && <Info className="w-4 h-4 text-cyan-400 shrink-0" />}
            <span className="whitespace-normal leading-snug">{toast.text}</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
