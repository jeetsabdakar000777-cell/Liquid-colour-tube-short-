import { ColorId } from '../types/game';

// Check if a move from tube `from` to tube `to` is valid according to liquid rules
export function canPour(
  tubes: ColorId[][],
  fromIndex: number,
  toIndex: number,
  lockedIndices: Set<number> = new Set()
): { valid: boolean; units: number; color?: ColorId } {
  if (fromIndex === toIndex) return { valid: false, units: 0 };
  if (lockedIndices.has(fromIndex) || lockedIndices.has(toIndex)) return { valid: false, units: 0 };

  const source = tubes[fromIndex];
  const dest = tubes[toIndex];

  if (!source || source.length === 0) return { valid: false, units: 0 };
  if (!dest || dest.length >= 4) return { valid: false, units: 0 };

  // Don't pour if source is already a completed full single-color tube and dest is empty (wasteful move)
  if (source.length === 4 && source.every((c) => c === source[0]) && dest.length === 0) {
    return { valid: false, units: 0 };
  }

  const topColor = source[source.length - 1];

  // Destination must be empty OR have matching top color
  if (dest.length > 0) {
    const destTopColor = dest[dest.length - 1];
    if (destTopColor !== topColor) {
      return { valid: false, units: 0 };
    }
  }

  const freeSpace = 4 - dest.length;
  if (freeSpace <= 0) return { valid: false, units: 0 };

  // Pour 1 unit (single layer) per move for precise, predictable gameplay
  return {
    valid: true,
    units: 1,
    color: topColor,
  };
}

// Execute the pour and return new state
export function executePour(
  tubes: ColorId[][],
  fromIndex: number,
  toIndex: number
): { newTubes: ColorId[][]; unitsPoured: number; color: ColorId } | null {
  const check = canPour(tubes, fromIndex, toIndex);
  if (!check.valid || !check.color) return null;

  const newTubes = tubes.map((t) => [...t]);
  const color = check.color;
  const units = check.units;

  for (let i = 0; i < units; i++) {
    newTubes[fromIndex].pop();
    newTubes[toIndex].push(color);
  }

  return { newTubes, unitsPoured: units, color };
}

// Check if entire puzzle is solved
export function isLevelSolved(tubes: ColorId[][]): boolean {
  for (const tube of tubes) {
    if (tube.length === 0) continue;
    if (tube.length < 4) return false;
    const first = tube[0];
    if (!tube.every((c) => c === first)) return false;
  }
  return true;
}

// State serializer for BFS search visited set
function serializeState(tubes: ColorId[][]): string {
  // Sort empty tubes and uniform representation to avoid symmetric explosion
  return tubes.map((t) => t.join('-')).join('|');
}

// Fast BFS solver to find optimal next move (Hint) & shortest solution length
export function findSolution(
  initialTubes: ColorId[][],
  maxDepth = 32
): { solved: boolean; moves: { from: number; to: number }[]; optimalSteps: number } {
  if (isLevelSolved(initialTubes)) {
    return { solved: true, moves: [], optimalSteps: 0 };
  }

  interface QueueNode {
    tubes: ColorId[][];
    moves: { from: number; to: number }[];
  }

  const queue: QueueNode[] = [{ tubes: initialTubes, moves: [] }];
  const visited = new Set<string>();
  visited.add(serializeState(initialTubes));

  let iterations = 0;
  const maxIterations = 12000;

  while (queue.length > 0 && iterations < maxIterations) {
    iterations++;
    const current = queue.shift()!;

    if (current.moves.length >= maxDepth) continue;

    for (let from = 0; from < current.tubes.length; from++) {
      if (current.tubes[from].length === 0) continue;

      for (let to = 0; to < current.tubes.length; to++) {
        if (from === to) continue;

        const check = canPour(current.tubes, from, to);
        if (!check.valid) continue;

        const result = executePour(current.tubes, from, to);
        if (!result) continue;

        if (isLevelSolved(result.newTubes)) {
          const solutionMoves = [...current.moves, { from, to }];
          return {
            solved: true,
            moves: solutionMoves,
            optimalSteps: solutionMoves.length,
          };
        }

        const serialized = serializeState(result.newTubes);
        if (!visited.has(serialized)) {
          visited.add(serialized);
          queue.push({
            tubes: result.newTubes,
            moves: [...current.moves, { from, to }],
          });
        }
      }
    }
  }

  // Fallback: If deep search reached limit, return simple greedy valid move
  for (let from = 0; from < initialTubes.length; from++) {
    for (let to = 0; to < initialTubes.length; to++) {
      if (from !== to && canPour(initialTubes, from, to).valid) {
        return { solved: true, moves: [{ from, to }], optimalSteps: 12 };
      }
    }
  }

  return { solved: false, moves: [], optimalSteps: 10 };
}
