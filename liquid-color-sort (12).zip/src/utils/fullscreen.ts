// Immersive Fullscreen and Screen Orientation Utilities for Android & Mobile Web

export function isFullscreenActive(): boolean {
  if (typeof document === 'undefined') return false;
  const doc = document as any;
  return Boolean(
    doc.fullscreenElement ||
    doc.webkitFullscreenElement ||
    doc.mozFullScreenElement ||
    doc.msFullscreenElement
  );
}

export function enterFullscreen(): Promise<void> {
  if (typeof document === 'undefined') return Promise.resolve();
  const docEl = document.documentElement as any;

  // Try screen orientation lock if supported
  try {
    if (typeof screen !== 'undefined' && screen.orientation && (screen.orientation as any).lock) {
      (screen.orientation as any).lock('portrait').catch(() => {});
    }
  } catch {
    // ignore
  }

  if (isFullscreenActive()) {
    return Promise.resolve();
  }

  try {
    if (docEl.requestFullscreen) {
      return docEl.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
    } else if (docEl.webkitRequestFullscreen) {
      return docEl.webkitRequestFullscreen();
    } else if (docEl.mozRequestFullScreen) {
      return docEl.mozRequestFullScreen();
    } else if (docEl.msRequestFullscreen) {
      return docEl.msRequestFullscreen();
    }
  } catch {
    // ignore
  }
  return Promise.resolve();
}

export function exitFullscreen(): Promise<void> {
  if (typeof document === 'undefined') return Promise.resolve();
  const doc = document as any;

  try {
    if (typeof screen !== 'undefined' && screen.orientation && screen.orientation.unlock) {
      screen.orientation.unlock();
    }
  } catch {
    // ignore
  }

  if (!isFullscreenActive()) {
    return Promise.resolve();
  }

  try {
    if (doc.exitFullscreen) {
      return doc.exitFullscreen().catch(() => {});
    } else if (doc.webkitExitFullscreen) {
      return doc.webkitExitFullscreen();
    } else if (doc.mozCancelFullScreen) {
      return doc.mozCancelFullScreen();
    } else if (doc.msExitFullscreen) {
      return doc.msExitFullscreen();
    }
  } catch {
    // ignore
  }
  return Promise.resolve();
}

export function toggleFullscreen(): void {
  if (isFullscreenActive()) {
    exitFullscreen();
  } else {
    enterFullscreen();
  }
}
