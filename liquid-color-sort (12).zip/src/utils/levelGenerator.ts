import { ColorId, LevelData, SpecialChallengeType } from '../types/game';
import { findSolution } from './solver';

// Seeded PRNG (Mulberry32) for deterministic, reproducible 200 levels
function createPRNG(seed: number) {
  let s = seed | 0;
  return function () {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Tier 1: Maximally distinct fundamental colors across the entire color wheel
// (Ruby Red, Sapphire Blue, Sun Yellow, Emerald Green, Citrus Orange, Amethyst Purple, Neon Cyan, Rose Pink)
const DISTINCT_PALETTE_TIER1: ColorId[] = [
  'red',
  'blue',
  'yellow',
  'green',
  'orange',
  'purple',
  'cyan',
  'pink',
];

// Tier 2: Additional high-contrast colors for larger 9+ color puzzles
const DISTINCT_PALETTE_TIER2: ColorId[] = [
  'lime',
  'deepBlue',
  'magenta',
  'teal',
  'coral',
  'violet',
  'skyBlue',
  'turquoise',
];

// Returns a set of `count` colors guaranteed to have maximum chromatic contrast
export function getDistinctPalette(count: number, prng: () => number): ColorId[] {
  if (count <= DISTINCT_PALETTE_TIER1.length) {
    const tier1 = [...DISTINCT_PALETTE_TIER1];
    for (let i = tier1.length - 1; i > 0; i--) {
      const j = Math.floor(prng() * (i + 1));
      [tier1[i], tier1[j]] = [tier1[j], tier1[i]];
    }
    return tier1.slice(0, count);
  } else {
    const tier1 = [...DISTINCT_PALETTE_TIER1];
    const tier2 = [...DISTINCT_PALETTE_TIER2];
    for (let i = tier2.length - 1; i > 0; i--) {
      const j = Math.floor(prng() * (i + 1));
      [tier2[i], tier2[j]] = [tier2[j], tier2[i]];
    }
    const needed = count - tier1.length;
    const combined = [...tier1, ...tier2.slice(0, needed)];
    for (let i = combined.length - 1; i > 0; i--) {
      const j = Math.floor(prng() * (i + 1));
      [combined[i], combined[j]] = [combined[j], combined[i]];
    }
    return combined;
  }
}

// Hand-crafted starter levels (1 to 5) with distinct bright colors & gentle learning curve
const STARTER_LEVELS: Record<number, LevelData> = {
  1: {
    levelNumber: 1,
    colorsCount: 2,
    tubesCount: 3,
    initialTubes: [
      ['red', 'blue', 'red', 'blue'],
      ['blue', 'red', 'blue', 'red'],
      [],
    ],
    threeStarMoves: 4,
    twoStarMoves: 6,
    specialType: 'normal',
  },
  2: {
    levelNumber: 2,
    colorsCount: 3,
    tubesCount: 4,
    initialTubes: [
      ['red', 'yellow', 'blue', 'red'],
      ['blue', 'red', 'yellow', 'blue'],
      ['yellow', 'blue', 'red', 'yellow'],
      [],
    ],
    threeStarMoves: 7,
    twoStarMoves: 10,
    specialType: 'normal',
  },
  3: {
    levelNumber: 3,
    colorsCount: 3,
    tubesCount: 5,
    initialTubes: [
      ['green', 'red', 'yellow', 'green'],
      ['yellow', 'green', 'red', 'yellow'],
      ['red', 'yellow', 'green', 'red'],
      [],
      [],
    ],
    threeStarMoves: 8,
    twoStarMoves: 12,
    specialType: 'normal',
  },
  4: {
    levelNumber: 4,
    colorsCount: 4,
    tubesCount: 6,
    initialTubes: [
      ['red', 'blue', 'green', 'yellow'],
      ['yellow', 'red', 'blue', 'green'],
      ['green', 'yellow', 'red', 'blue'],
      ['blue', 'green', 'yellow', 'red'],
      [],
      [],
    ],
    threeStarMoves: 11,
    twoStarMoves: 15,
    specialType: 'normal',
  },
  5: {
    levelNumber: 5,
    colorsCount: 4,
    tubesCount: 6,
    initialTubes: [
      ['purple', 'orange', 'cyan', 'lime'],
      ['lime', 'purple', 'orange', 'cyan'],
      ['cyan', 'lime', 'purple', 'orange'],
      ['orange', 'cyan', 'lime', 'purple'],
      [],
      [],
    ],
    threeStarMoves: 13,
    twoStarMoves: 17,
    specialType: 'normal',
  },
};

// Generate a guaranteed solvable and challenging level by reverse-scrambling solved state
function generateLevel(levelNumber: number): LevelData {
  if (STARTER_LEVELS[levelNumber]) {
    return STARTER_LEVELS[levelNumber];
  }

  const prng = createPRNG(levelNumber * 104729 + 7919);

  let colorsCount = 4;
  let tubesCount = 6;
  let scrambleSteps = 25;
  let specialType: SpecialChallengeType = 'normal';

  // Smooth & steep progression from Level 6 to 200
  if (levelNumber <= 10) {
    colorsCount = 4;
    tubesCount = 6; // 4 color tubes + 2 empty
    scrambleSteps = 24 + (levelNumber - 5) * 4;
  } else if (levelNumber <= 20) {
    colorsCount = 5;
    tubesCount = 7; // 5 color tubes + 2 empty
    scrambleSteps = 40 + (levelNumber - 10) * 3;
    if (levelNumber === 15) specialType = 'limitedMoves';
    if (levelNumber === 18) specialType = 'timeChallenge';
  } else if (levelNumber <= 35) {
    colorsCount = 5;
    tubesCount = levelNumber <= 26 ? 7 : 8; // 5 colors + 2 or 3 empty
    scrambleSteps = 60 + (levelNumber - 20) * 3;
    if (levelNumber % 7 === 0) specialType = 'limitedMoves';
    if (levelNumber === 30) specialType = 'mystery';
  } else if (levelNumber <= 55) {
    colorsCount = 6;
    tubesCount = levelNumber <= 45 ? 8 : 9;
    scrambleSteps = 80 + (levelNumber - 35) * 3;
    if (levelNumber % 9 === 0) specialType = 'lockedTube';
    if (levelNumber % 11 === 0) specialType = 'mystery';
    if (levelNumber === 42) specialType = 'timeChallenge';
    if (levelNumber === 50) specialType = 'noUndo';
  } else if (levelNumber <= 80) {
    colorsCount = 7;
    tubesCount = levelNumber <= 68 ? 9 : 10;
    scrambleSteps = 110 + (levelNumber - 55) * 3;
    if (levelNumber % 8 === 0) specialType = 'limitedMoves';
    if (levelNumber % 10 === 0) specialType = 'mystery';
    if (levelNumber % 14 === 0) specialType = 'lockedTube';
    if (levelNumber === 72) specialType = 'timeChallenge';
  } else if (levelNumber <= 115) {
    colorsCount = 8;
    tubesCount = levelNumber <= 98 ? 10 : 11;
    scrambleSteps = 150 + (levelNumber - 80) * 3;
    if (levelNumber % 7 === 0) specialType = 'mystery';
    if (levelNumber % 9 === 0) specialType = 'lockedTube';
    if (levelNumber % 13 === 0) specialType = 'noUndo';
  } else if (levelNumber <= 155) {
    colorsCount = 9;
    tubesCount = levelNumber <= 135 ? 11 : 12;
    scrambleSteps = 190 + (levelNumber - 115) * 3;
    if (levelNumber % 6 === 0) specialType = 'limitedMoves';
    if (levelNumber % 8 === 0) specialType = 'mystery';
    if (levelNumber % 10 === 0) specialType = 'lockedTube';
  } else if (levelNumber < 200) {
    colorsCount = 10;
    tubesCount = 12;
    scrambleSteps = 240 + (levelNumber - 155) * 2;
    if (levelNumber % 5 === 0) specialType = 'mystery';
    if (levelNumber % 7 === 0) specialType = 'lockedTube';
    if (levelNumber % 9 === 0) specialType = 'limitedMoves';
  } else if (levelNumber === 200) {
    // LEVEL 200: GRAND FINALE OF STANDARD CAMPAIGN
    colorsCount = 11;
    tubesCount = 13;
    scrambleSteps = 320;
    specialType = 'limitedMoves';
  } else {
    // UNLIMITED ENDLESS MASTER LEVELS (201+)
    const cycle = (levelNumber - 201) % 20;
    colorsCount = 6 + (cycle % 6);
    const extraEmpty = cycle % 4 === 0 ? 3 : 2;
    tubesCount = colorsCount + extraEmpty;
    scrambleSteps = 160 + (cycle * 8);

    if (levelNumber % 11 === 0) {
      specialType = 'mystery';
    } else if (levelNumber % 9 === 0) {
      specialType = 'limitedMoves';
    } else if (levelNumber % 13 === 0) {
      specialType = 'lockedTube';
    } else if (levelNumber % 17 === 0) {
      specialType = 'timeChallenge';
    } else if (levelNumber % 19 === 0) {
      specialType = 'noUndo';
    } else {
      specialType = 'normal';
    }
  }

  // Pick distinct, high-contrast colors
  const selectedColors = getDistinctPalette(colorsCount, prng);

  // Initialize sorted tubes (each color has 4 units) + empty tubes
  const tubes: ColorId[][] = [];
  for (let i = 0; i < colorsCount; i++) {
    tubes.push([selectedColors[i], selectedColors[i], selectedColors[i], selectedColors[i]]);
  }
  while (tubes.length < tubesCount) {
    tubes.push([]);
  }

  // Deterministically scramble by reverse pours with anti-clumping logic
  let lastFrom = -1;
  let lastTo = -1;

  for (let step = 0; step < scrambleSteps; step++) {
    const validSources: number[] = [];
    for (let i = 0; i < tubes.length; i++) {
      if (tubes[i].length > 0) validSources.push(i);
    }
    if (validSources.length === 0) break;

    const fromIdx = validSources[Math.floor(prng() * validSources.length)];

    const validDests: number[] = [];
    for (let j = 0; j < tubes.length; j++) {
      if (j !== fromIdx && tubes[j].length < 4) {
        if (!(fromIdx === lastTo && j === lastFrom)) {
          validDests.push(j);
        }
      }
    }

    if (validDests.length === 0) continue;

    const toIdx = validDests[Math.floor(prng() * validDests.length)];

    const maxMove = Math.min(tubes[fromIdx].length, 4 - tubes[toIdx].length);
    const amount = maxMove > 1 && prng() > 0.75 ? 2 : 1;

    for (let u = 0; u < amount; u++) {
      const unit = tubes[fromIdx].pop()!;
      tubes[toIdx].push(unit);
    }

    lastFrom = fromIdx;
    lastTo = toIdx;
  }

  // Verify that all color tubes are well-mixed with 4 units each and empty tubes remain empty
  const allUnits: ColorId[] = [];
  tubes.forEach((t) => {
    while (t.length > 0) {
      allUnits.push(t.pop()!);
    }
  });

  const activeTubesCount = colorsCount;
  for (let i = 0; i < activeTubesCount; i++) {
    tubes[i] = [];
  }
  for (let i = activeTubesCount; i < tubesCount; i++) {
    tubes[i] = [];
  }

  let unitIdx = 0;
  for (let layer = 0; layer < 4; layer++) {
    for (let t = 0; t < activeTubesCount; t++) {
      if (unitIdx < allUnits.length) {
        tubes[t].push(allUnits[unitIdx++]);
      }
    }
  }

  // Ensure no tube starts already solved
  for (let t = 0; t < activeTubesCount; t++) {
    if (tubes[t].length === 4 && tubes[t].every((c) => c === tubes[t][0])) {
      const nextT = (t + 1) % activeTubesCount;
      const topCurrent = tubes[t].pop()!;
      const topNext = tubes[nextT].pop()!;
      tubes[t].push(topNext);
      tubes[nextT].push(topCurrent);
    }
  }

  // Compute solver targets for 3-star and 2-star metrics
  const solution = findSolution(tubes, 30);
  const baseMoves = Math.max(solution.optimalSteps, colorsCount * 3 + 2);
  const threeStarMoves = baseMoves + 3;
  const twoStarMoves = baseMoves + 7;

  let maxMoves: number | undefined;
  if (specialType === 'limitedMoves') {
    maxMoves = threeStarMoves + Math.max(4, Math.floor(colorsCount * 1.5));
  }

  let timeLimitSeconds: number | undefined;
  if (specialType === 'timeChallenge') {
    timeLimitSeconds = 75 + colorsCount * 15;
  }

  return {
    levelNumber,
    colorsCount,
    tubesCount,
    initialTubes: tubes.map((t) => [...t]),
    threeStarMoves,
    twoStarMoves,
    specialType,
    maxMoves,
    timeLimitSeconds,
  };
}

// Generate a dedicated, guaranteed crystal-clear Daily Challenge Level
export function getDailyChallengeLevel(dateStr?: string, variationIndex: number = 0): LevelData {
  const d = dateStr ? new Date(dateStr) : new Date();
  const dayNum = d.getDate();
  const monthNum = d.getMonth() + 1;
  const yearNum = d.getFullYear();
  const dateSeed = yearNum * 10000 + monthNum * 100 + dayNum;
  const variationSeed = dateSeed * 7919 + 104729 + (variationIndex * 99991) + (variationIndex > 0 ? 54321 : 0);
  const prng = createPRNG(variationSeed);

  // Daily Challenge has 5 or 6 vibrant, distinct colors with 7 or 8 tubes
  const colorsCount = 5 + ((dayNum + variationIndex) % 2);
  const tubesCount = colorsCount + 2;
  const scrambleSteps = 75 + ((dayNum * 7 + variationIndex * 17) % 18) * 3;

  // Select 5-6 maximally contrasting colors from Tier 1
  const selectedColors = getDistinctPalette(colorsCount, prng);

  const tubes: ColorId[][] = [];
  for (let i = 0; i < colorsCount; i++) {
    tubes.push([selectedColors[i], selectedColors[i], selectedColors[i], selectedColors[i]]);
  }
  while (tubes.length < tubesCount) {
    tubes.push([]);
  }

  let lastFrom = -1;
  let lastTo = -1;

  for (let step = 0; step < scrambleSteps; step++) {
    const validSources: number[] = [];
    for (let i = 0; i < tubes.length; i++) {
      if (tubes[i].length > 0) validSources.push(i);
    }
    if (validSources.length === 0) break;

    const fromIdx = validSources[Math.floor(prng() * validSources.length)];

    const validDests: number[] = [];
    for (let j = 0; j < tubes.length; j++) {
      if (j !== fromIdx && tubes[j].length < 4) {
        if (!(fromIdx === lastTo && j === lastFrom)) {
          validDests.push(j);
        }
      }
    }

    if (validDests.length === 0) continue;

    const toIdx = validDests[Math.floor(prng() * validDests.length)];
    const maxMove = Math.min(tubes[fromIdx].length, 4 - tubes[toIdx].length);
    const amount = maxMove > 1 && prng() > 0.7 ? 2 : 1;

    for (let u = 0; u < amount; u++) {
      const unit = tubes[fromIdx].pop()!;
      tubes[toIdx].push(unit);
    }

    lastFrom = fromIdx;
    lastTo = toIdx;
  }

  const allUnits: ColorId[] = [];
  tubes.forEach((t) => {
    while (t.length > 0) {
      allUnits.push(t.pop()!);
    }
  });

  const activeTubesCount = colorsCount;
  for (let i = 0; i < activeTubesCount; i++) {
    tubes[i] = [];
  }
  for (let i = activeTubesCount; i < tubesCount; i++) {
    tubes[i] = [];
  }

  let unitIdx = 0;
  for (let layer = 0; layer < 4; layer++) {
    for (let t = 0; t < activeTubesCount; t++) {
      if (unitIdx < allUnits.length) {
        tubes[t].push(allUnits[unitIdx++]);
      }
    }
  }

  // Ensure no tube starts already solved
  for (let t = 0; t < activeTubesCount; t++) {
    if (tubes[t].length === 4 && tubes[t].every((c) => c === tubes[t][0])) {
      const nextT = (t + 1) % activeTubesCount;
      const topCurrent = tubes[t].pop()!;
      const topNext = tubes[nextT].pop()!;
      tubes[t].push(topNext);
      tubes[nextT].push(topCurrent);
    }
  }

  const solution = findSolution(tubes, 30);
  const baseMoves = Math.max(solution.optimalSteps, colorsCount * 3 + 2);

  return {
    levelNumber: 9999, // Special Daily Challenge Level ID
    colorsCount,
    tubesCount,
    initialTubes: tubes.map((t) => [...t]),
    threeStarMoves: baseMoves + 3,
    twoStarMoves: baseMoves + 7,
    specialType: 'normal',
  };
}

// Cache of generated levels
const LEVEL_CACHE: Map<number, LevelData> = new Map();

export function isUnlimitedLevel(levelNumber: number): boolean {
  return levelNumber > 200;
}

export function getLevelData(levelNumber: number): LevelData {
  const safeLevel = Math.max(1, Math.floor(levelNumber));
  if (!LEVEL_CACHE.has(safeLevel)) {
    LEVEL_CACHE.set(safeLevel, generateLevel(safeLevel));
  }
  return LEVEL_CACHE.get(safeLevel)!;
}

export function getAllStandardLevels(): LevelData[] {
  const list: LevelData[] = [];
  for (let i = 1; i <= 200; i++) {
    list.push(getLevelData(i));
  }
  return list;
}
