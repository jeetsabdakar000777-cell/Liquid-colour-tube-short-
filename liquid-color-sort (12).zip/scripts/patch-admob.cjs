const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, '..', 'android', 'capacitor-community-admob');
const targetDir = path.join(__dirname, '..', 'node_modules', '@capacitor-community', 'admob', 'android');

if (fs.existsSync(srcDir) && fs.existsSync(targetDir)) {
  try {
    fs.cpSync(srcDir, targetDir, { recursive: true });
    // Remove any leftover .kt files in targetDir
    function removeKt(dir) {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          removeKt(full);
        } else if (entry.isFile() && entry.name.endsWith('.kt')) {
          fs.unlinkSync(full);
        }
      }
    }
    removeKt(targetDir);
    console.log('[patch-admob] Synced pure Java capacitor-community-admob to node_modules');
  } catch (err) {
    console.warn('[patch-admob] Sync error:', err.message);
  }
}
