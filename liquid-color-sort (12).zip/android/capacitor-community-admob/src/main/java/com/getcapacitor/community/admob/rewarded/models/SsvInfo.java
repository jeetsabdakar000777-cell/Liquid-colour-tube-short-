package com.getcapacitor.community.admob.rewarded.models;

import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;

public class SsvInfo {
    private final String customData;
    private final String userId;

    public SsvInfo(String customData, String userId) {
        this.customData = customData;
        this.userId = userId;
    }

    public SsvInfo(PluginCall pluginCall) {
        JSObject ssv = pluginCall != null ? pluginCall.getObject("ssv") : null;
        this.customData = ssv != null ? ssv.getString("customData") : null;
        this.userId = ssv != null ? ssv.getString("userId") : null;
    }

    public SsvInfo() {
        this(null, null);
    }

    public String getCustomData() {
        return customData;
    }

    public String getUserId() {
        return userId;
    }

    public boolean getHasInfo() {
        return customData != null || userId != null;
    }

    public boolean hasInfo() {
        return customData != null || userId != null;
    }
}
