package com.getcapacitor.community.admob.helpers;

public enum AuthorizationStatusEnum {
    AUTHORIZED("authorized");

    private final String status;

    AuthorizationStatusEnum(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
