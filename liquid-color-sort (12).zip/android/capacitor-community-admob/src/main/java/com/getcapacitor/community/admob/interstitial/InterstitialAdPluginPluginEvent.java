package com.getcapacitor.community.admob.interstitial;

import com.getcapacitor.community.admob.models.LoadPluginEventNames;

public class InterstitialAdPluginPluginEvent implements LoadPluginEventNames {
    public static final InterstitialAdPluginPluginEvent INSTANCE = new InterstitialAdPluginPluginEvent();

    public static final String Loaded = "interstitialAdLoaded";
    public static final String FailedToLoad = "interstitialAdFailedToLoad";
    public static final String Showed = "interstitialAdShowed";
    public static final String FailedToShow = "interstitialAdFailedToShow";
    public static final String Dismissed = "interstitialAdDismissed";
    public static final String AdImpression = "interstitialAdImpression";

    @Override
    public String getShowed() {
        return Showed;
    }

    @Override
    public String getFailedToShow() {
        return FailedToShow;
    }

    @Override
    public String getDismissed() {
        return Dismissed;
    }
}
