package com.getcapacitor.community.admob.appopen;

public class AppOpenAdPluginEvents {
    public static final String Loaded = "appOpenAdLoaded";
    public static final String FailedToLoad = "appOpenAdFailedToLoad";
    public static final String Opened = "appOpenAdOpened";
    public static final String Closed = "appOpenAdClosed";
    public static final String FailedToShow = "appOpenAdFailedToShow";
    public static final String AdImpression = "appOpenAdImpression";
}
