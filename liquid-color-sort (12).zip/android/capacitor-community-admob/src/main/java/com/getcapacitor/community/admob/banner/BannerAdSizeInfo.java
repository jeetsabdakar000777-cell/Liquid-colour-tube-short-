package com.getcapacitor.community.admob.banner;

import com.getcapacitor.JSObject;
import com.google.android.gms.ads.AdView;
import java.util.Objects;

public class BannerAdSizeInfo extends JSObject {
    public BannerAdSizeInfo(int width, int height) {
        super();
        super.put("width", width);
        super.put("height", height);
    }

    public BannerAdSizeInfo(AdView mAdView) {
        this(mAdView != null && mAdView.getAdSize() != null ? mAdView.getAdSize().getWidth() : 0,
             mAdView != null && mAdView.getAdSize() != null ? mAdView.getAdSize().getHeight() : 0);
    }
}
