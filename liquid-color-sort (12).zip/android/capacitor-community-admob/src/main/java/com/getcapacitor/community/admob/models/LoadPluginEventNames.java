package com.getcapacitor.community.admob.models;

public interface LoadPluginEventNames {
    String getShowed();
    String getFailedToShow();
    String getDismissed();
}
