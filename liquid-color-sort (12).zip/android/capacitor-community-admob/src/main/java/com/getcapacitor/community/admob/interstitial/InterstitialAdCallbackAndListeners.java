package com.getcapacitor.community.admob.interstitial;

import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import com.getcapacitor.community.admob.helpers.FullscreenPluginCallback;
import com.getcapacitor.community.admob.models.AdMobPluginError;
import com.getcapacitor.community.admob.models.AdMobRevenueData;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.common.util.BiConsumer;

public class InterstitialAdCallbackAndListeners {
    public static final InterstitialAdCallbackAndListeners INSTANCE = new InterstitialAdCallbackAndListeners();

    public InterstitialAdLoadCallback getInterstitialAdLoadCallback(
        final PluginCall call,
        final BiConsumer<String, JSObject> notifyListenersFunction
    ) {
        return new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(InterstitialAd ad) {
                Boolean immersiveMode = call.getBoolean("immersiveMode");
                ad.setFullScreenContentCallback(new FullscreenPluginCallback(InterstitialAdPluginPluginEvent.INSTANCE, notifyListenersFunction));
                ad.setImmersiveMode(immersiveMode != null ? immersiveMode : false);

                ad.setOnPaidEventListener(adValue -> {
                    ResponseInfo responseInfo = ad.getResponseInfo();
                    String networkName = responseInfo != null && responseInfo.getMediationAdapterClassName() != null ? responseInfo.getMediationAdapterClassName() : "";
                    String impressionId = responseInfo != null && responseInfo.getResponseId() != null ? responseInfo.getResponseId() : "";
                    AdMobRevenueData revenueData = new AdMobRevenueData(adValue, ad.getAdUnitId(), networkName, impressionId);
                    notifyListenersFunction.accept(InterstitialAdPluginPluginEvent.AdImpression, revenueData);
                });

                AdInterstitialExecutor.preparedAds.put(ad.getAdUnitId(), ad);
                AdInterstitialExecutor.lastPreparedAdId = ad.getAdUnitId();

                JSObject adInfo = new JSObject();
                adInfo.put("adUnitId", ad.getAdUnitId());
                call.resolve(adInfo);

                notifyListenersFunction.accept(InterstitialAdPluginPluginEvent.Loaded, adInfo);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                AdMobPluginError adMobError = new AdMobPluginError(adError);
                notifyListenersFunction.accept(InterstitialAdPluginPluginEvent.FailedToLoad, adMobError);
                call.reject(adError.getMessage());
            }
        };
    }
}
