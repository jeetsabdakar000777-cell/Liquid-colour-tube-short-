package com.getcapacitor.community.admob.banner;

public enum BannerAdPluginEvents {
    SizeChanged("bannerAdSizeChanged"),
    Closed("bannerAdClosed"),
    FailedToLoad("bannerAdFailedToLoad"),
    Opened("bannerAdOpened"),
    Loaded("bannerAdLoaded"),
    Clicked("bannerAdClicked"),
    AdImpression("bannerAdImpression"),
    AdPaid("bannerAdPaid");

    private final String webEventName;

    BannerAdPluginEvents(String webEventName) {
        this.webEventName = webEventName;
    }

    public String getWebEventName() {
        return webEventName;
    }
}
