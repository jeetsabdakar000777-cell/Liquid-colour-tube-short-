package com.getcapacitor.community.admob.rewarded;

import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import com.getcapacitor.community.admob.helpers.FullscreenPluginCallback;
import com.getcapacitor.community.admob.models.AdMobPluginError;
import com.getcapacitor.community.admob.models.AdMobRevenueData;
import com.getcapacitor.community.admob.models.AdOptions;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions;
import com.google.android.gms.common.util.BiConsumer;

public class RewardedAdCallbackAndListeners {
    public static final RewardedAdCallbackAndListeners INSTANCE = new RewardedAdCallbackAndListeners();

    public OnUserEarnedRewardListener getOnUserEarnedRewardListener(final PluginCall call, final BiConsumer<String, JSObject> notifyListenersFunction) {
        return (RewardItem item) -> {
            JSObject response = new JSObject();
            response.put("type", item != null ? item.getType() : "");
            response.put("amount", item != null ? item.getAmount() : 0);
            notifyListenersFunction.accept(RewardAdPluginEvents.Rewarded, response);
            call.resolve(response);
        };
    }

    public RewardedAdLoadCallback getRewardedAdLoadCallback(
        final PluginCall call,
        final BiConsumer<String, JSObject> notifyListenersFunction,
        final AdOptions adOptions
    ) {
        return new RewardedAdLoadCallback() {
            @Override
            public void onAdLoaded(RewardedAd ad) {
                Boolean immersiveMode = call.getBoolean("immersiveMode");
                ad.setImmersiveMode(immersiveMode != null ? immersiveMode : false);
                ad.setFullScreenContentCallback(new FullscreenPluginCallback(RewardAdPluginEvents.INSTANCE, notifyListenersFunction));

                ad.setOnPaidEventListener(adValue -> {
                    ResponseInfo responseInfo = ad.getResponseInfo();
                    String networkName = responseInfo != null && responseInfo.getMediationAdapterClassName() != null ? responseInfo.getMediationAdapterClassName() : "";
                    String impressionId = responseInfo != null && responseInfo.getResponseId() != null ? responseInfo.getResponseId() : "";
                    AdMobRevenueData revenueData = new AdMobRevenueData(adValue, ad.getAdUnitId(), networkName, impressionId);
                    notifyListenersFunction.accept(RewardAdPluginEvents.AdImpression, revenueData);
                });

                if (adOptions != null && adOptions.ssvInfo != null && adOptions.ssvInfo.getHasInfo()) {
                    ServerSideVerificationOptions.Builder ssvOptions = new ServerSideVerificationOptions.Builder();
                    if (adOptions.ssvInfo.getCustomData() != null) {
                        ssvOptions.setCustomData(adOptions.ssvInfo.getCustomData());
                    }
                    if (adOptions.ssvInfo.getUserId() != null) {
                        ssvOptions.setUserId(adOptions.ssvInfo.getUserId());
                    }
                    ad.setServerSideVerificationOptions(ssvOptions.build());
                }

                AdRewardExecutor.preparedAds.put(ad.getAdUnitId(), ad);
                AdRewardExecutor.lastPreparedAdId = ad.getAdUnitId();

                JSObject adInfo = new JSObject();
                adInfo.put("adUnitId", ad.getAdUnitId());
                call.resolve(adInfo);

                notifyListenersFunction.accept(RewardAdPluginEvents.Loaded, adInfo);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                AdMobPluginError adMobError = new AdMobPluginError(adError);
                notifyListenersFunction.accept(RewardAdPluginEvents.FailedToLoad, adMobError);
                call.reject(adError.getMessage());
            }
        };
    }
}
