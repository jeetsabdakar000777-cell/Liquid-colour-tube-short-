package com.getcapacitor.community.admob.appopen;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import com.getcapacitor.community.admob.models.AdMobPluginError;
import com.getcapacitor.community.admob.models.AdMobRevenueData;
import java.util.LinkedHashMap;
import java.util.Map;

public class AppOpenAdPlugin {

    public interface EventNotifier {
        void notify(String eventName, JSObject data);
    }

    private final Map<String, AppOpenAdManager> preparedManagers = new LinkedHashMap<>();
    private String lastPreparedAdId = null;

    private void runOnMain(Activity activity, Runnable runnable) {
        if (activity != null) {
            activity.runOnUiThread(runnable);
        } else {
            new Handler(Looper.getMainLooper()).post(runnable);
        }
    }

    public void loadAppOpen(Context context, Activity activity, PluginCall call, EventNotifier notifier) {
        if (context == null) {
            call.reject("Context is not available");
            return;
        }

        String adUnitId = call.getString("adId");
        if (adUnitId == null) {
            call.reject("adId is required");
            return;
        }

        Context appContext = context.getApplicationContext();
        runOnMain(activity, () -> {
            AppOpenAdManager manager = preparedManagers.get(adUnitId);
            if (manager == null) {
                manager = new AppOpenAdManager(adUnitId);
                preparedManagers.put(adUnitId, manager);
            }

            manager.loadAd(
                appContext,
                () -> {
                    lastPreparedAdId = adUnitId;
                    JSObject adInfo = new JSObject();
                    adInfo.put("adUnitId", adUnitId);
                    if (notifier != null) {
                        notifier.notify(AppOpenAdPluginEvents.Loaded, adInfo);
                    }
                    call.resolve(adInfo);
                },
                (loadAdError) -> {
                    String errorMessage = loadAdError != null ? loadAdError.getMessage() : "Failed to load App Open Ad";
                    int errorCode = loadAdError != null ? loadAdError.getCode() : -1;
                    if (notifier != null) {
                        notifier.notify(AppOpenAdPluginEvents.FailedToLoad, new AdMobPluginError(errorCode, errorMessage));
                    }
                    call.reject(errorMessage);
                },
                (adValue, networkName, impressionId) -> {
                    AdMobRevenueData revenueData = new AdMobRevenueData(adValue, adUnitId, networkName, impressionId);
                    if (notifier != null) {
                        notifier.notify(AppOpenAdPluginEvents.AdImpression, revenueData);
                    }
                }
            );
        });
    }

    public void showAppOpen(Activity activity, PluginCall call, EventNotifier notifier) {
        if (activity == null) {
            call.reject("Activity is not available");
            return;
        }

        String requestedAdId = call.getString("adId");
        String adId = requestedAdId != null ? requestedAdId : lastPreparedAdId;

        runOnMain(activity, () -> {
            AppOpenAdManager manager = adId != null ? preparedManagers.get(adId) : null;

            if (manager == null || !manager.isAdLoaded()) {
                call.reject("App Open Ad is not loaded");
                return;
            }

            manager.showAdIfAvailable(
                activity,
                () -> {
                    if (notifier != null) {
                        notifier.notify(AppOpenAdPluginEvents.Opened, new JSObject());
                    }
                },
                () -> {
                    preparedManagers.remove(adId);
                    if (adId != null && adId.equals(lastPreparedAdId)) {
                        lastPreparedAdId = null;
                        for (Map.Entry<String, AppOpenAdManager> entry : preparedManagers.entrySet()) {
                            if (entry.getValue().isAdLoaded()) {
                                lastPreparedAdId = entry.getKey();
                            }
                        }
                    }
                    if (notifier != null) {
                        notifier.notify(AppOpenAdPluginEvents.Closed, new JSObject());
                    }
                    call.resolve();
                },
                (adError) -> {
                    preparedManagers.remove(adId);
                    if (adId != null && adId.equals(lastPreparedAdId)) {
                        lastPreparedAdId = null;
                        for (Map.Entry<String, AppOpenAdManager> entry : preparedManagers.entrySet()) {
                            if (entry.getValue().isAdLoaded()) {
                                lastPreparedAdId = entry.getKey();
                            }
                        }
                    }
                    String errorMessage = adError != null ? adError.getMessage() : "Failed to show App Open Ad";
                    int errorCode = adError != null ? adError.getCode() : -1;
                    if (notifier != null) {
                        notifier.notify(AppOpenAdPluginEvents.FailedToShow, new AdMobPluginError(errorCode, errorMessage));
                    }
                    call.reject(errorMessage);
                }
            );
        });
    }

    public void isAppOpenLoaded(Activity activity, PluginCall call) {
        String requestedAdId = call.getString("adId");
        String adId = requestedAdId != null ? requestedAdId : lastPreparedAdId;
        runOnMain(activity, () -> {
            boolean loaded = false;
            if (adId != null) {
                AppOpenAdManager manager = preparedManagers.get(adId);
                if (manager != null) {
                    loaded = manager.isAdLoaded();
                }
            }
            JSObject result = new JSObject();
            result.put("value", loaded);
            call.resolve(result);
        });
    }
}
