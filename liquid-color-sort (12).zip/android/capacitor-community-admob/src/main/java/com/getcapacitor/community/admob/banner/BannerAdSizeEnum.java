package com.getcapacitor.community.admob.banner;

import com.google.android.gms.ads.AdSize;

public enum BannerAdSizeEnum {
    BANNER(AdSize.BANNER),
    FULL_BANNER(AdSize.FULL_BANNER),
    LARGE_BANNER(AdSize.LARGE_BANNER),
    MEDIUM_RECTANGLE(AdSize.MEDIUM_RECTANGLE),
    LEADERBOARD(AdSize.LEADERBOARD),
    ADAPTIVE_BANNER(AdSize.INVALID),
    SMART_BANNER(AdSize.SMART_BANNER);

    private final AdSize size;

    BannerAdSizeEnum(AdSize size) {
        this.size = size;
    }

    public AdSize getSize() {
        return size;
    }

    @Override
    public String toString() {
        return name();
    }
}
