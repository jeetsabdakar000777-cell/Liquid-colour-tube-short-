package com.getcapacitor.community.admob.models;

import com.getcapacitor.JSObject;
import com.google.android.gms.ads.AdValue;

public class AdMobRevenueData extends JSObject {
    public AdMobRevenueData(AdValue adValue, String adUnitId, String networkName, String impressionId) {
        super();
        put("adUnitId", adUnitId != null ? adUnitId : "");
        if (adValue != null) {
            put("valueMicros", adValue.getValueMicros());
            put("currencyCode", adValue.getCurrencyCode() != null ? adValue.getCurrencyCode() : "USD");
            put("precision", adValue.getPrecisionType());
        }
        put("networkName", networkName != null ? networkName : "");
        put("impressionId", impressionId != null ? impressionId : "");
    }
}
