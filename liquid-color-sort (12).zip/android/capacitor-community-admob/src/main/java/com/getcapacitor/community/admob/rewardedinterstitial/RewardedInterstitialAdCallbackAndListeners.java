package com.getcapacitor.community.admob.rewardedinterstitial;

import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import com.getcapacitor.community.admob.helpers.FullscreenPluginCallback;
import com.getcapacitor.community.admob.models.AdMobPluginError;
import com.getcapacitor.community.admob.models.AdMobRevenueData;
import com.getcapacitor.community.admob.models.AdOptions;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import com.google.android.gms.common.util.BiConsumer;

public class RewardedInterstitialAdCallbackAndListeners {
    public static final RewardedInterstitialAdCallbackAndListeners INSTANCE = new RewardedInterstitialAdCallbackAndListeners();

    public OnUserEarnedRewardListener getOnUserEarnedRewardListener(final PluginCall call, final BiConsumer<String, JSObject> notifyListenersFunction) {
        return (RewardItem item) -> {
            JSObject response = new JSObject();
            response.put("type", item != null ? item.getType() : "");
            response.put("amount", item != null ? item.getAmount() : 0);
            notifyListenersFunction.accept(RewardInterstitialAdPluginEvents.Rewarded, response);
            call.resolve(response);
        };
    }

    public RewardedInterstitialAdLoadCallback getRewardedAdLoadCallback(
        final PluginCall call,
        final BiConsumer<String, JSObject> notifyListenersFunction,
        final AdOptions adOptions
    ) {
        return new RewardedInterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(RewardedInterstitialAd ad) {
                ad.setFullScreenContentCallback(new FullscreenPluginCallback(RewardInterstitialAdPluginEvents.INSTANCE, notifyListenersFunction));

                ad.setOnPaidEventListener(adValue -> {
                    ResponseInfo responseInfo = ad.getResponseInfo();
                    String networkName = responseInfo != null && responseInfo.getMediationAdapterClassName() != null ? responseInfo.getMediationAdapterClassName() : "";
                    String impressionId = responseInfo != null && responseInfo.getResponseId() != null ? responseInfo.getResponseId() : "";
                    AdMobRevenueData revenueData = new AdMobRevenueData(adValue, ad.getAdUnitId(), networkName, impressionId);
                    notifyListenersFunction.accept(RewardInterstitialAdPluginEvents.AdImpression, revenueData);
                });

                AdRewardInterstitialExecutor.preparedAds.put(ad.getAdUnitId(), ad);
                AdRewardInterstitialExecutor.lastPreparedAdId = ad.getAdUnitId();

                JSObject adInfo = new JSObject();
                adInfo.put("adUnitId", ad.getAdUnitId());
                call.resolve(adInfo);

                notifyListenersFunction.accept(RewardInterstitialAdPluginEvents.Loaded, adInfo);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                AdMobPluginError adMobError = new AdMobPluginError(adError);
                notifyListenersFunction.accept(RewardInterstitialAdPluginEvents.FailedToLoad, adMobError);
                call.reject(adError.getMessage());
            }
        };
    }
}
