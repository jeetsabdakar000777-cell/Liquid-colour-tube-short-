package com.getcapacitor.community.admob.models;

import com.getcapacitor.JSObject;
import com.google.android.gms.ads.AdError;

public class AdMobPluginError extends JSObject {
    public AdMobPluginError(int code, String message) {
        super();
        super.put("code", code);
        super.put("message", message != null ? message : "");
    }

    public AdMobPluginError(AdError adError) {
        this(adError != null ? adError.getCode() : 0, adError != null ? adError.getMessage() : "Unknown error");
    }
}
