package com.getcapacitor.community.admob.rewardedinterstitial;

import com.getcapacitor.community.admob.models.LoadPluginEventNames;

public class RewardInterstitialAdPluginEvents implements LoadPluginEventNames {
    public static final RewardInterstitialAdPluginEvents INSTANCE = new RewardInterstitialAdPluginEvents();

    public static final String Loaded = "onRewardedInterstitialAdLoaded";
    public static final String FailedToLoad = "onRewardedInterstitialAdFailedToLoad";
    public static final String Rewarded = "onRewardedInterstitialAdReward";
    public static final String Showed = "onRewardedInterstitialAdShowed";
    public static final String FailedToShow = "onRewardedInterstitialAdFailedToShow";
    public static final String Dismissed = "onRewardedInterstitialAdDismissed";
    public static final String AdImpression = "onRewardedInterstitialAdImpression";

    @Override
    public String getShowed() {
        return Showed;
    }

    @Override
    public String getFailedToShow() {
        return FailedToShow;
    }

    @Override
    public String getDismissed() {
        return Dismissed;
    }
}
