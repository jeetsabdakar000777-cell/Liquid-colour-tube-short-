package com.getcapacitor.community.admob.helpers;

import com.getcapacitor.JSObject;
import com.getcapacitor.community.admob.models.AdMobPluginError;
import com.getcapacitor.community.admob.models.LoadPluginEventNames;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.common.util.BiConsumer;

public class FullscreenPluginCallback extends FullScreenContentCallback {
    private final LoadPluginEventNames loadPluginObject;
    private final BiConsumer<String, JSObject> notifyListenersFunction;
    private final Runnable onCompleted;

    public FullscreenPluginCallback(LoadPluginEventNames loadPluginObject, BiConsumer<String, JSObject> notifyListenersFunction) {
        this(loadPluginObject, notifyListenersFunction, null);
    }

    public FullscreenPluginCallback(LoadPluginEventNames loadPluginObject, BiConsumer<String, JSObject> notifyListenersFunction, Runnable onCompleted) {
        this.loadPluginObject = loadPluginObject;
        this.notifyListenersFunction = notifyListenersFunction;
        this.onCompleted = onCompleted;
    }

    @Override
    public void onAdShowedFullScreenContent() {
        if (notifyListenersFunction != null && loadPluginObject != null) {
            notifyListenersFunction.accept(loadPluginObject.getShowed(), new JSObject());
        }
    }

    @Override
    public void onAdFailedToShowFullScreenContent(AdError adError) {
        if (onCompleted != null) {
            onCompleted.run();
        }
        if (notifyListenersFunction != null && loadPluginObject != null) {
            AdMobPluginError adMobError = new AdMobPluginError(adError);
            notifyListenersFunction.accept(loadPluginObject.getFailedToShow(), adMobError);
        }
    }

    @Override
    public void onAdDismissedFullScreenContent() {
        if (onCompleted != null) {
            onCompleted.run();
        }
        if (notifyListenersFunction != null && loadPluginObject != null) {
            notifyListenersFunction.accept(loadPluginObject.getDismissed(), new JSObject());
        }
    }
}
