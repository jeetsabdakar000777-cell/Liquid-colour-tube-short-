package com.getcapacitor.community.admob.rewarded;

import com.getcapacitor.community.admob.models.LoadPluginEventNames;

public class RewardAdPluginEvents implements LoadPluginEventNames {
    public static final RewardAdPluginEvents INSTANCE = new RewardAdPluginEvents();

    public static final String Loaded = "onRewardedVideoAdLoaded";
    public static final String FailedToLoad = "onRewardedVideoAdFailedToLoad";
    public static final String Rewarded = "onRewardedVideoAdReward";
    public static final String Showed = "onRewardedVideoAdShowed";
    public static final String FailedToShow = "onRewardedVideoAdFailedToShow";
    public static final String Dismissed = "onRewardedVideoAdDismissed";
    public static final String AdImpression = "onRewardedVideoAdImpression";

    @Override
    public String getShowed() {
        return Showed;
    }

    @Override
    public String getFailedToShow() {
        return FailedToShow;
    }

    @Override
    public String getDismissed() {
        return Dismissed;
    }
}
