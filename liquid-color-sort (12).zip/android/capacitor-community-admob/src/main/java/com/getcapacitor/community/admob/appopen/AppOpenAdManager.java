package com.getcapacitor.community.admob.appopen;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class AppOpenAdManager {
    public interface OnPaidEventListener {
        void onPaid(AdValue adValue, String networkName, String impressionId);
    }

    public interface OnFailedListener {
        void onFailed(LoadAdError error);
    }

    public interface OnFailedToShowListener {
        void onFailedToShow(AdError error);
    }

    private final String adUnitId;
    private AppOpenAd appOpenAd = null;
    private boolean isLoadingAd = false;
    private boolean isShowingAd = false;

    public AppOpenAdManager(String adUnitId) {
        this.adUnitId = adUnitId;
    }

    public String getAdUnitId() {
        return adUnitId;
    }

    public boolean isAdLoaded() {
        return appOpenAd != null;
    }

    public void loadAd(
        Context context,
        Runnable onLoaded,
        OnFailedListener onFailed,
        OnPaidEventListener onPaidEvent
    ) {
        if (appOpenAd != null) {
            if (onLoaded != null) {
                onLoaded.run();
            }
            return;
        }

        if (isLoadingAd) {
            if (onFailed != null) {
                onFailed.onFailed(null);
            }
            return;
        }

        isLoadingAd = true;
        AdRequest request = new AdRequest.Builder().build();

        AppOpenAd.load(
            context,
            adUnitId,
            request,
            new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull AppOpenAd ad) {
                    appOpenAd = ad;
                    isLoadingAd = false;
                    ad.setOnPaidEventListener(adValue -> {
                        ResponseInfo responseInfo = ad.getResponseInfo();
                        String networkName = responseInfo != null && responseInfo.getMediationAdapterClassName() != null ? responseInfo.getMediationAdapterClassName() : "";
                        String impressionId = responseInfo != null && responseInfo.getResponseId() != null ? responseInfo.getResponseId() : "";
                        if (onPaidEvent != null) {
                            onPaidEvent.onPaid(adValue, networkName, impressionId);
                        }
                    });
                    if (onLoaded != null) {
                        onLoaded.run();
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    isLoadingAd = false;
                    if (onFailed != null) {
                        onFailed.onFailed(loadAdError);
                    }
                }
            }
        );
    }

    public void showAdIfAvailable(
        Activity activity,
        Runnable onOpened,
        Runnable onClosed,
        OnFailedToShowListener onFailedToShow
    ) {
        if (appOpenAd == null || isShowingAd) {
            if (onFailedToShow != null) {
                onFailedToShow.onFailedToShow(null);
            }
            return;
        }

        isShowingAd = true;
        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdShowedFullScreenContent() {
                if (onOpened != null) {
                    onOpened.run();
                }
            }

            @Override
            public void onAdDismissedFullScreenContent() {
                appOpenAd = null;
                isShowingAd = false;
                if (onClosed != null) {
                    onClosed.run();
                }
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                appOpenAd = null;
                isShowingAd = false;
                if (onFailedToShow != null) {
                    onFailedToShow.onFailedToShow(adError);
                }
            }
        });

        appOpenAd.show(activity);
    }
}
